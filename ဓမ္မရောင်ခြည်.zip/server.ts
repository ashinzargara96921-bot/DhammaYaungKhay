import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import multer from 'multer';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const PORT = 3000;
const ROOT_DIR = process.cwd();
const DATA_DIR = path.join(ROOT_DIR, 'data');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'dhamma_contents.json');
const ADMIN_FILE = path.join(DATA_DIR, 'admin.json');
const ANDROID_DIR = path.join(ROOT_DIR, 'android-app');

fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify([], null, 2), 'utf8');
}

const SESSION_SECRET =
  process.env.SESSION_SECRET?.trim() ||
  crypto.createHash('sha256').update(ROOT_DIR + '_dhamma_yaung_chi').digest('hex');

const HAS_SESSION_SECRET_ENV = Boolean(process.env.SESSION_SECRET?.trim());
const COOKIE_NAME = 'dhamma_admin_session';

export interface DhammaRecord {
  id: string;
  title: string;
  preacher: string;
  category: string;
  description: string;
  mediaType: 'MP3' | 'MP4';
  mediaUrl: string;
  storedFileName?: string;
  durationText: string;
  createdAt: string;
  updatedAt: string;
}

interface AdminRecord {
  email: string;
  salt: string;
  passwordHash: string;
  createdAt: string;
}

const ALLOWED_CATEGORIES = [
  'တရားတော်',
  'ပရိတ်တော်',
  'ပဋ္ဌာန်း',
  'ဝိပဿနာ',
  'ဓမ္မစကြာ',
  'ဂါထာတော်',
];

function readContents(): DhammaRecord[] {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeContents(records: DhammaRecord[]): void {
  fs.writeFileSync(DB_FILE, JSON.stringify(records, null, 2), 'utf8');
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function getEnvStatus() {
  return {
    hasAdminEmail: Boolean(process.env.ADMIN_EMAIL?.trim()),
    hasAdminPassword: Boolean(process.env.ADMIN_PASSWORD?.trim()),
    hasSessionSecret: HAS_SESSION_SECRET_ENV,
  };
}

function getConfiguredAdminInfo(): { admin: AdminRecord | null; source: 'env' | 'local_file' | 'unconfigured' } {
  const envEmail = process.env.ADMIN_EMAIL?.trim();
  const envPassword = process.env.ADMIN_PASSWORD?.trim();
  if (envEmail && envPassword) {
    const salt = 'env_configured_salt';
    return {
      admin: {
        email: envEmail,
        salt,
        passwordHash: hashPassword(envPassword, salt),
        createdAt: new Date().toISOString(),
      },
      source: 'env',
    };
  }
  if (fs.existsSync(ADMIN_FILE)) {
    try {
      return {
        admin: JSON.parse(fs.readFileSync(ADMIN_FILE, 'utf8')) as AdminRecord,
        source: 'local_file',
      };
    } catch {
      return { admin: null, source: 'unconfigured' };
    }
  }
  return { admin: null, source: 'unconfigured' };
}

function getConfiguredAdmin(): AdminRecord | null {
  return getConfiguredAdminInfo().admin;
}

function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie;
  if (!header) return {};
  const result: Record<string, string> = {};
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const key = part.slice(0, idx).trim();
      const val = decodeURIComponent(part.slice(idx + 1).trim());
      result[key] = val;
    }
  }
  return result;
}

function extractSessionToken(req: Request): string | undefined {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const bearer = authHeader.slice(7).trim();
    if (bearer) return bearer;
  }
  const cookies = parseCookies(req);
  return cookies[COOKIE_NAME];
}

function isHttpsRequest(req: Request): boolean {
  const forwardedProto = req.headers['x-forwarded-proto'];
  if (typeof forwardedProto === 'string') {
    return forwardedProto.split(',')[0].trim() === 'https';
  }
  return req.secure;
}

function setSessionCookie(req: Request, res: Response, token: string): void {
  const https = isHttpsRequest(req);
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: https ? 'none' : 'lax',
    secure: https,
    partitioned: https,
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

function createSessionToken(email: string): string {
  const payload = Buffer.from(
    JSON.stringify({ email, exp: Date.now() + 7 * 24 * 60 * 60 * 1000 })
  ).toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  return `${payload}.${sig}`;
}

function verifySessionToken(token?: string): { email: string } | null {
  if (!token || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  if (sig.length !== expectedSig.length) return null;
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) {
    return null;
  }
  try {
    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!decoded.email || typeof decoded.exp !== 'number' || decoded.exp < Date.now()) {
      return null;
    }
    return { email: decoded.email };
  } catch {
    return null;
  }
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const token = extractSessionToken(req);
  const session = verifySessionToken(token);
  const admin = getConfiguredAdmin();
  if (!session || !admin || session.email.toLowerCase() !== admin.email.toLowerCase()) {
    res.status(401).json({ error: 'စီမံခန့်ခွဲသူ (Admin) အဖြစ် ဝင်ရောက်ရန် လိုအပ်ပါသည်' });
    return;
  }
  next();
}

// SSE Clients for real-time public updates
const sseClients = new Set<Response>();
function broadcastContentsUpdate(): void {
  const data = JSON.stringify({ type: 'sync', items: readContents() });
  for (const client of sseClients) {
    client.write(`data: ${data}\n\n`);
  }
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowedExts = new Set(['.mp3', '.mp4', '.m4a', '.wav', '.ogg', '.webm']);
    const safeExt = allowedExts.has(ext)
      ? ext
      : file.mimetype.startsWith('video/')
      ? '.mp4'
      : '.mp3';
    cb(null, `dhamma_${Date.now()}_${crypto.randomBytes(4).toString('hex')}${safeExt}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 250 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowedExts = new Set(['.mp3', '.mp4', '.m4a', '.wav', '.ogg', '.webm']);
    if (
      allowedExts.has(ext) ||
      file.mimetype.startsWith('audio/') ||
      file.mimetype.startsWith('video/')
    ) {
      cb(null, true);
    } else {
      cb(new Error('MP3 သို့မဟုတ် MP4 ဖိုင်များသာ တင်သွင်းနိုင်ပါသည်'));
    }
  },
});

function collectAndroidFiles(dir: string, baseDir: string): { path: string; content: string }[] {
  if (!fs.existsSync(dir)) return [];
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const results: { path: string; content: string }[] = [];
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    const relPath = path.relative(baseDir, fullPath).replace(/\\/g, '/');
    if (entry.isDirectory()) {
      results.push(...collectAndroidFiles(fullPath, baseDir));
    } else if (!entry.name.endsWith('.jpg') && !entry.name.endsWith('.png')) {
      results.push({
        path: relPath,
        content: fs.readFileSync(fullPath, 'utf8'),
      });
    }
  }
  return results.sort((a, b) => a.path.localeCompare(b.path));
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Real-time SSE stream for public users (no login required)
  app.get('/api/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    sseClients.add(res);
    res.write(`data: ${JSON.stringify({ type: 'sync', items: readContents() })}\n\n`);

    const keepAlive = setInterval(() => {
      res.write(': keepalive\n\n');
    }, 25000);

    req.on('close', () => {
      clearInterval(keepAlive);
      sseClients.delete(res);
    });
  });

  // Public Dhamma list (no login required)
  app.get('/api/dhamma', (_req, res) => {
    res.json({ items: readContents() });
  });

  // RFC 7233 Byte-Range MP3/MP4 media streaming endpoint (supports GET and HEAD)
  const serveMedia = (req: Request, res: Response) => {
    const safeName = path.basename(req.params.filename);
    const filePath = path.join(UPLOADS_DIR, safeName);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'မီဒီယာဖိုင် မတွေ့ရှိပါ' });
      return;
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const ext = path.extname(safeName).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.mp3': 'audio/mpeg',
      '.mp4': 'video/mp4',
      '.m4a': 'audio/mp4',
      '.wav': 'audio/wav',
      '.ogg': 'audio/ogg',
      '.webm': 'video/webm',
    };
    const contentType = mimeMap[ext] || 'application/octet-stream';

    const commonHeaders: Record<string, string | number> = {
      'Content-Type': contentType,
      'Accept-Ranges': 'bytes',
      'Content-Disposition': 'inline',
      'Cache-Control': 'public, max-age=3600, no-transform',
      'X-Content-Type-Options': 'nosniff',
    };

    const range = req.headers.range;
    if (range) {
      const match = /^bytes=(\d*)-(\d*)$/i.exec(range.trim());
      if (!match) {
        res.writeHead(416, {
          ...commonHeaders,
          'Content-Range': `bytes */${fileSize}`,
        });
        res.end();
        return;
      }

      const startStr = match[1];
      const endStr = match[2];
      let start: number;
      let end: number;

      if (startStr === '' && endStr !== '') {
        // Suffix byte range: bytes=-500
        const suffixLength = parseInt(endStr, 10);
        if (Number.isNaN(suffixLength) || suffixLength <= 0) {
          res.writeHead(416, { ...commonHeaders, 'Content-Range': `bytes */${fileSize}` });
          res.end();
          return;
        }
        start = Math.max(0, fileSize - suffixLength);
        end = fileSize - 1;
      } else if (startStr !== '') {
        start = parseInt(startStr, 10);
        end = endStr !== '' ? Math.min(parseInt(endStr, 10), fileSize - 1) : fileSize - 1;
      } else {
        res.writeHead(416, { ...commonHeaders, 'Content-Range': `bytes */${fileSize}` });
        res.end();
        return;
      }

      if (Number.isNaN(start) || Number.isNaN(end) || start < 0 || start >= fileSize || start > end) {
        res.writeHead(416, {
          ...commonHeaders,
          'Content-Range': `bytes */${fileSize}`,
        });
        res.end();
        return;
      }

      const chunkSize = end - start + 1;
      res.writeHead(206, {
        ...commonHeaders,
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Content-Length': chunkSize,
      });

      if (req.method === 'HEAD') {
        res.end();
        return;
      }

      const stream = fs.createReadStream(filePath, { start, end });
      stream.on('error', () => {
        if (!res.headersSent) res.status(500).end();
        else res.end();
      });
      res.on('close', () => stream.destroy());
      stream.pipe(res);
      return;
    }

    res.writeHead(200, {
      ...commonHeaders,
      'Content-Length': fileSize,
    });

    if (req.method === 'HEAD') {
      res.end();
      return;
    }

    const stream = fs.createReadStream(filePath);
    stream.on('error', () => {
      if (!res.headersSent) res.status(500).end();
      else res.end();
    });
    res.on('close', () => stream.destroy());
    stream.pipe(res);
  };

  app.route('/api/media/:filename').get(serveMedia).head(serveMedia);

  // Admin status
  app.get('/api/admin/status', (req, res) => {
    const { admin, source } = getConfiguredAdminInfo();
    const session = verifySessionToken(extractSessionToken(req));
    const isAuthenticated = Boolean(
      session && admin && session.email.toLowerCase() === admin.email.toLowerCase()
    );
    res.json({
      isConfigured: Boolean(admin),
      isAuthenticated,
      email: isAuthenticated ? session?.email : null,
      authSource: source,
      envStatus: getEnvStatus(),
    });
  });

  // First-time Admin setup when ADMIN_EMAIL / ADMIN_PASSWORD are not set
  app.post('/api/admin/setup', (req, res) => {
    if (getConfiguredAdmin()) {
      res.status(409).json({ error: 'စီမံသူအကောင့် သတ်မှတ်ပြီးသား ဖြစ်ပါသည်' });
      return;
    }
    const { email, password } = req.body ?? {};
    if (typeof email !== 'string' || !email.includes('@') || typeof password !== 'string' || password.length < 6) {
      res.status(400).json({ error: 'မှန်ကန်သော အီးမေးလ်နှင့် အနည်းဆုံး ၆ လုံးပါ စကားဝှက် ထည့်သွင်းပါ' });
      return;
    }
    const salt = crypto.randomBytes(16).toString('hex');
    const record: AdminRecord = {
      email: email.trim(),
      salt,
      passwordHash: hashPassword(password, salt),
      createdAt: new Date().toISOString(),
    };
    fs.writeFileSync(ADMIN_FILE, JSON.stringify(record, null, 2), 'utf8');
    const token = createSessionToken(record.email);
    setSessionCookie(req, res, token);
    res.json({ ok: true, email: record.email, token });
  });

  // Admin Login
  app.post('/api/admin/login', (req, res) => {
    const envStatus = getEnvStatus();
    if (envStatus.hasAdminEmail !== envStatus.hasAdminPassword) {
      res.status(500).json({
        error: 'ဆာဗာတွင် ADMIN_EMAIL နှင့် ADMIN_PASSWORD နှစ်ခုလုံး ပြည့်စုံစွာ သတ်မှတ်ရန် လိုအပ်ပါသည်',
      });
      return;
    }
    const admin = getConfiguredAdmin();
    if (!admin) {
      res.status(400).json({ error: 'စီမံသူအကောင့် မသတ်မှတ်ရသေးပါ' });
      return;
    }
    const { email, password } = req.body ?? {};
    if (typeof email !== 'string' || typeof password !== 'string' || !email.trim() || !password) {
      res.status(400).json({ error: 'အီးမေးလ်နှင့် စကားဝှက် ထည့်သွင်းပါ' });
      return;
    }
    const computed = hashPassword(password, admin.salt);
    const emailMatches = email.trim().toLowerCase() === admin.email.toLowerCase();
    const hashMatches =
      computed.length === admin.passwordHash.length &&
      crypto.timingSafeEqual(Buffer.from(computed), Buffer.from(admin.passwordHash));

    if (!emailMatches || !hashMatches) {
      res.status(401).json({ error: 'အီးမေးလ် သို့မဟုတ် စကားဝှက် မှားယွင်းနေပါသည်' });
      return;
    }
    const token = createSessionToken(admin.email);
    setSessionCookie(req, res, token);
    res.json({ ok: true, email: admin.email, token });
  });

  app.post('/api/admin/logout', (req, res) => {
    const https = isHttpsRequest(req);
    res.clearCookie(COOKIE_NAME, {
      httpOnly: true,
      sameSite: https ? 'none' : 'lax',
      secure: https,
      partitioned: https,
    });
    res.json({ ok: true });
  });

  // Admin Upload MP3 / MP4
  app.post('/api/admin/dhamma', requireAdmin, upload.single('mediaFile'), (req, res) => {
    const { title, preacher, category, description, mediaType, externalUrl, durationText } = req.body ?? {};
    if (!title || !preacher) {
      if (req.file) fs.unlinkSync(req.file.path);
      res.status(400).json({ error: 'တရားခေါင်းစဉ်နှင့် ဆရာတော်အမည် ထည့်သွင်းပါ' });
      return;
    }

    const validType: 'MP3' | 'MP4' = mediaType === 'MP4' ? 'MP4' : 'MP3';
    const validCat = ALLOWED_CATEGORIES.includes(category) ? category : ALLOWED_CATEGORIES[0];

    let resolvedUrl = typeof externalUrl === 'string' ? externalUrl.trim() : '';
    let storedFileName: string | undefined;

    if (req.file) {
      storedFileName = req.file.filename;
      resolvedUrl = `/api/media/${req.file.filename}`;
    }

    if (!resolvedUrl) {
      res.status(400).json({ error: 'MP3/MP4 ဖိုင် သို့မဟုတ် တိုက်ရိုက် Media URL ထည့်သွင်းပါ' });
      return;
    }

    const now = new Date().toISOString();
    const record: DhammaRecord = {
      id: `dhamma_${crypto.randomBytes(6).toString('hex')}`,
      title: String(title).trim().slice(0, 200),
      preacher: String(preacher).trim().slice(0, 160),
      category: validCat,
      description: String(description || '').trim().slice(0, 2000),
      mediaType: validType,
      mediaUrl: resolvedUrl,
      storedFileName,
      durationText: String(durationText || '00:00').trim().slice(0, 32),
      createdAt: now,
      updatedAt: now,
    };

    const items = readContents();
    items.unshift(record);
    writeContents(items);
    broadcastContentsUpdate();
    res.status(201).json({ item: record });
  });

  // Admin Edit Metadata
  app.put('/api/admin/dhamma/:id', requireAdmin, (req, res) => {
    const items = readContents();
    const idx = items.findIndex((i) => i.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'တရားတော် မတွေ့ရှိပါ' });
      return;
    }
    const { title, preacher, category, description, mediaType, durationText } = req.body ?? {};
    const existing = items[idx];
    const updated: DhammaRecord = {
      ...existing,
      title: title ? String(title).trim().slice(0, 200) : existing.title,
      preacher: preacher ? String(preacher).trim().slice(0, 160) : existing.preacher,
      category: ALLOWED_CATEGORIES.includes(category) ? category : existing.category,
      description: description !== undefined ? String(description).trim().slice(0, 2000) : existing.description,
      mediaType: mediaType === 'MP4' ? 'MP4' : mediaType === 'MP3' ? 'MP3' : existing.mediaType,
      durationText: durationText ? String(durationText).trim().slice(0, 32) : existing.durationText,
      updatedAt: new Date().toISOString(),
    };
    items[idx] = updated;
    writeContents(items);
    broadcastContentsUpdate();
    res.json({ item: updated });
  });

  // Admin Delete Content + Uploaded File
  app.delete('/api/admin/dhamma/:id', requireAdmin, (req, res) => {
    const items = readContents();
    const target = items.find((i) => i.id === req.params.id);
    if (!target) {
      res.status(404).json({ error: 'တရားတော် မတွေ့ရှိပါ' });
      return;
    }
    if (target.storedFileName) {
      const filePath = path.join(UPLOADS_DIR, path.basename(target.storedFileName));
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }
    const next = items.filter((i) => i.id !== req.params.id);
    writeContents(next);
    broadcastContentsUpdate();
    res.json({ ok: true });
  });

  // Expose native Android Kotlin + Firebase setup files for inspection
  app.get('/api/android-files', (_req, res) => {
    const files = collectAndroidFiles(ANDROID_DIR, ANDROID_DIR);
    res.json({ files });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ဓမ္မရောင်ခြည် server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
