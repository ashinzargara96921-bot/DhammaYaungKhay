export type MediaType = 'MP3' | 'MP4';

export const DHAMMA_CATEGORIES = [
  'တရားတော်',
  'ပရိတ်တော်',
  'ပဋ္ဌာန်း',
  'ဝိပဿနာ',
  'ဓမ္မစကြာ',
  'ဂါထာတော်',
] as const;

export const ALL_CATEGORY_LABEL = 'အားလုံး';

export interface DhammaContent {
  id: string;
  title: string;
  preacher: string;
  category: string;
  description: string;
  mediaType: MediaType;
  mediaUrl: string;
  durationText: string;
  createdAt: string;
  updatedAt: string;
}

export interface AdminStatus {
  isConfigured: boolean;
  isAuthenticated: boolean;
  email: string | null;
  authSource?: 'env' | 'local_file' | 'unconfigured';
  envStatus?: {
    hasAdminEmail: boolean;
    hasAdminPassword: boolean;
    hasSessionSecret: boolean;
  };
}

export interface AndroidSourceFile {
  path: string;
  content: string;
}
