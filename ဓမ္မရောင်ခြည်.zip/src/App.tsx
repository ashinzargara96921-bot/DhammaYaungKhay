import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Home, Search, Heart, Code2, ShieldCheck } from 'lucide-react';
import {
  ALL_CATEGORY_LABEL,
  AdminStatus,
  DHAMMA_CATEGORIES,
  DhammaContent,
  MediaType,
} from './types/dhamma';
import { DhammaCard } from './components/DhammaCard';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { AdminPanel } from './components/AdminPanel';
import { AndroidSourceExplorer } from './components/AndroidSourceExplorer';

type NavTab = 'home' | 'search' | 'favorites' | 'android' | 'admin';

const HERO_IMAGE = '/src/assets/images/hero_pagoda_sunrise_1794637503898.jpg';
const BUDDHA_IMAGE = '/src/assets/images/buddha_statue_gold_1794637504297.jpg';
const LOTUS_IMAGE = '/src/assets/images/lotus_temple_offering_1794637504377.jpg';
const MONASTERY_IMAGE = '/src/assets/images/monastery_dusk_gold_1794637505447.jpg';

const FAVORITES_STORAGE_KEY = 'dhamma_yaung_chi_favorites';
const RECENTS_STORAGE_KEY = 'dhamma_yaung_chi_recents';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [items, setItems] = useState<DhammaContent[]>([]);
  const [loading, setLoading] = useState(true);
  const [adminStatus, setAdminStatus] = useState<AdminStatus>({
    isConfigured: false,
    isAuthenticated: false,
    email: null,
  });

  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string>(ALL_CATEGORY_LABEL);
  const [mediaFilter, setMediaFilter] = useState<MediaType | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [favoritesTabMode, setFavoritesTabMode] = useState<'favorites' | 'recents'>('favorites');

  // Public Local Persistence (no login required)
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });
  const [recentIds, setRecentIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(RECENTS_STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  // Active Media Playback
  const [activeAudioTrack, setActiveAudioTrack] = useState<DhammaContent | null>(null);
  const [audioPlayNonce, setAudioPlayNonce] = useState(0);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [activeVideoItem, setActiveVideoItem] = useState<DhammaContent | null>(null);

  const fetchItems = useCallback(async () => {
    try {
      const res = await fetch('/api/dhamma');
      const data = await res.json();
      if (Array.isArray(data.items)) {
        setItems(data.items);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchAdminStatus = useCallback(async () => {
    try {
      const token = sessionStorage.getItem('dhamma_admin_token');
      const res = await fetch('/api/admin/status', {
        credentials: 'include',
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      });
      const data: AdminStatus = await res.json();
      if (!data.isAuthenticated && token) {
        sessionStorage.removeItem('dhamma_admin_token');
      }
      setAdminStatus(data);
    } catch {
      // Ignore transient failure
    }
  }, []);

  useEffect(() => {
    fetchItems();
    fetchAdminStatus();

    const eventSource = new EventSource('/api/events');
    eventSource.onmessage = (event) => {
      try {
        const parsed = JSON.parse(event.data);
        if (parsed.type === 'sync' && Array.isArray(parsed.items)) {
          setItems(parsed.items);
          setLoading(false);
        }
      } catch {
        // Ignore malformed SSE message
      }
    };
    return () => eventSource.close();
  }, [fetchItems, fetchAdminStatus]);

  useEffect(() => {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favoriteIds));
  }, [favoriteIds]);

  useEffect(() => {
    localStorage.setItem(RECENTS_STORAGE_KEY, JSON.stringify(recentIds));
  }, [recentIds]);

  const toggleFavorite = (id: string) => {
    setFavoriteIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [id, ...prev]
    );
  };

  const handlePlayItem = (item: DhammaContent) => {
    setRecentIds((prev) => [item.id, ...prev.filter((id) => id !== item.id)].slice(0, 30));
    if (item.mediaType === 'MP3') {
      setActiveVideoItem(null);
      setActiveAudioTrack(item);
      setAudioPlayNonce((n) => n + 1);
    } else {
      setActiveAudioTrack(null);
      setIsAudioPlaying(false);
      setActiveVideoItem(item);
    }
  };

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchCategory =
        selectedCategory === ALL_CATEGORY_LABEL || item.category === selectedCategory;
      const matchType = mediaFilter === 'ALL' || item.mediaType === mediaFilter;
      const q = searchQuery.trim().toLowerCase();
      const matchQuery =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.preacher.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q);
      return matchCategory && matchType && matchQuery;
    });
  }, [items, selectedCategory, mediaFilter, searchQuery]);

  const favoriteItems = useMemo(
    () => items.filter((i) => favoriteIds.includes(i.id)),
    [items, favoriteIds]
  );

  const recentItems = useMemo(() => {
    const map = new Map(items.map((i) => [i.id, i]));
    return recentIds.map((id) => map.get(id)).filter((x): x is DhammaContent => Boolean(x));
  }, [items, recentIds]);

  return (
    <div className="min-h-screen bg-[#160F0A] text-[#F6EFE4] pb-28 md:pb-12">
      {/* Strict 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 bg-[#160F0A]/90 backdrop-blur-md border-b border-[#422E1E]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className="text-lg sm:text-xl font-bold text-[#E8C668] tracking-tight whitespace-nowrap shrink-0 cursor-pointer"
          >
            ဓမ္မရောင်ခြည်
          </button>

          {/* Zone 2: 4 Single-line Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#CBBBA3]">
            <button
              type="button"
              onClick={() => setActiveTab('home')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors cursor-pointer ${
                activeTab === 'home'
                  ? 'text-[#E8C668] border-b border-[#D4AF37]'
                  : 'hover:text-[#F6EFE4]'
              }`}
            >
              ပင်မ
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('search')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors cursor-pointer ${
                activeTab === 'search'
                  ? 'text-[#E8C668] border-b border-[#D4AF37]'
                  : 'hover:text-[#F6EFE4]'
              }`}
            >
              ရှာဖွေရန်
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('favorites')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors cursor-pointer ${
                activeTab === 'favorites'
                  ? 'text-[#E8C668] border-b border-[#D4AF37]'
                  : 'hover:text-[#F6EFE4]'
              }`}
            >
              နှစ်သက်ရာ
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('android')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors cursor-pointer ${
                activeTab === 'android'
                  ? 'text-[#E8C668] border-b border-[#D4AF37]'
                  : 'hover:text-[#F6EFE4]'
              }`}
            >
              Android ကုဒ်
            </button>
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="shrink-0">
            <button
              type="button"
              onClick={() => setActiveTab('admin')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-[#E8C668] text-[#160F0A]'
                  : 'bg-[#D4AF37] text-[#160F0A] hover:bg-[#E8C668]'
              }`}
            >
              {adminStatus.isAuthenticated ? 'စီမံခန့်ခွဲမှု' : 'စီမံသူ ဝင်ရန်'}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-6 space-y-10">
        {activeTab === 'home' && (
          <>
            {/* Hero Buddhist Sanctuary Section */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-8 relative rounded-3xl overflow-hidden border border-[#422E1E] min-h-[280px] sm:min-h-[360px] bg-[#221811]">
                <img
                  src={HERO_IMAGE}
                  alt="ရွှေတိဂုံစေတီတော်နှင့် မြန်မာ့ဗုဒ္ဓသာသနာ ပုံရိပ်"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#160F0A] via-[#160F0A]/55 to-transparent" />
                <div className="relative z-10 h-full flex flex-col justify-end p-6 sm:p-8 max-w-2xl">
                  <h1 className="text-2xl sm:text-4xl font-bold text-[#E8C668] leading-snug text-balance">
                    တရားဓမ္မ ရောင်ခြည်ဖြင့် စိတ်နှလုံး အေးချမ်းပါစေ
                  </h1>
                  <p className="mt-2.5 text-sm sm:text-base text-[#F6EFE4]/90 leading-relaxed">
                    အကောင့်ဝင်ရန် မလိုဘဲ MP3 တရားတော် အသံဖိုင်များနှင့် MP4 ဗီဒီယို တရားတော်များကို အချိန်မရွေး တိုက်ရိုက်နားဆင် ကြည့်ရှုနိုင်ပါသည်။
                  </p>
                  <div className="mt-5 flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setActiveTab('search')}
                      className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#160F0A] text-sm font-semibold hover:bg-[#E8C668] transition-colors cursor-pointer"
                    >
                      တရားတော် ရှာဖွေရန်
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('android')}
                      className="px-5 py-2.5 rounded-xl bg-[#221811]/90 border border-[#D4AF37]/50 text-[#E8C668] text-sm font-medium hover:bg-[#2E2117] transition-colors cursor-pointer"
                    >
                      Kotlin & Firebase ကုဒ် ကြည့်ရန်
                    </button>
                  </div>
                </div>
              </div>

              {/* Side Buddhist Imagery Showcase */}
              <div className="lg:col-span-4 grid grid-cols-2 lg:grid-cols-1 gap-4">
                <div className="relative rounded-2xl overflow-hidden border border-[#422E1E] min-h-[140px] bg-[#221811]">
                  <img
                    src={BUDDHA_IMAGE}
                    alt="ရွှေဆင်းတုတော်မြတ်"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#160F0A]/90 via-[#160F0A]/30 to-transparent" />
                  <div className="relative z-10 h-full flex flex-col justify-end p-4">
                    <p className="text-sm font-semibold text-[#E8C668]">MP3 အသံတော်များ</p>
                    <p className="text-xs text-[#CBBBA3] tabular-nums">
                      {items.filter((i) => i.mediaType === 'MP3').length} ပုဒ်
                    </p>
                  </div>
                </div>

                <div className="relative rounded-2xl overflow-hidden border border-[#422E1E] min-h-[140px] bg-[#221811]">
                  <img
                    src={LOTUS_IMAGE}
                    alt="ကြာပန်းနှင့် ဆီမီးပူဇော်ပွဲ"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#160F0A]/90 via-[#160F0A]/30 to-transparent" />
                  <div className="relative z-10 h-full flex flex-col justify-end p-4">
                    <p className="text-sm font-semibold text-[#E8C668]">MP4 ဗီဒီယို တရားတော်</p>
                    <p className="text-xs text-[#CBBBA3] tabular-nums">
                      {items.filter((i) => i.mediaType === 'MP4').length} ခု
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Category & Media Type Filter Bar */}
            <section className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {[ALL_CATEGORY_LABEL, ...DHAMMA_CATEGORIES].map((cat) => {
                    const active = selectedCategory === cat;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-2 rounded-xl text-sm whitespace-nowrap shrink-0 border transition-colors cursor-pointer ${
                          active
                            ? 'bg-[#D4AF37] text-[#160F0A] border-[#D4AF37] font-semibold'
                            : 'bg-[#221811] text-[#CBBBA3] border-[#422E1E] hover:border-[#8F6F28]'
                        }`}
                      >
                        {cat}
                      </button>
                    );
                  })}
                </div>

                {/* Segmented Media Type Filter */}
                <div className="flex items-center gap-1 p-1 rounded-xl bg-[#221811] border border-[#422E1E]">
                  {(
                    [
                      { key: 'ALL', label: 'အားလုံး' },
                      { key: 'MP3', label: 'MP3 အသံ' },
                      { key: 'MP4', label: 'MP4 ဗီဒီယို' },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.key}
                      type="button"
                      onClick={() => setMediaFilter(opt.key)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                        mediaFilter === opt.key
                          ? 'bg-[#35261A] text-[#E8C668]'
                          : 'text-[#CBBBA3] hover:text-[#F6EFE4]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dhamma Content List */}
              {loading ? (
                <div className="py-16 text-center text-sm text-[#CBBBA3]">
                  တရားတော်များ ရယူနေပါသည်...
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="rounded-2xl border border-[#422E1E] bg-[#221811] overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
                  <div className="md:col-span-5 h-52 md:h-full">
                    <img
                      src={MONASTERY_IMAGE}
                      alt="မြန်မာ့ဘုန်းတော်ကြီးကျောင်း"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-7 p-6 sm:p-8">
                    <h2 className="text-lg font-semibold text-[#E8C668]">
                      တရားတော်များ မရှိသေးပါ
                    </h2>
                    <p className="mt-2 text-sm text-[#CBBBA3] leading-relaxed">
                      စီမံခန့်ခွဲသူ (Admin) မှ MP3 အသံတော် သို့မဟုတ် MP4 ဗီဒီယို တရားတော်များကို တင်သွင်းလိုက်သည်နှင့် ဤနေရာတွင် အချိန်နှင့်တစ်ပြေးညီ ပေါ်လာမည် ဖြစ်ပါသည်။
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveTab('admin')}
                      className="mt-4 px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#160F0A] text-sm font-semibold hover:bg-[#E8C668] transition-colors cursor-pointer"
                    >
                      စီမံသူမှ တရားတော် တင်သွင်းရန်
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {filteredItems.map((item) => (
                    <DhammaCard
                      key={item.id}
                      item={item}
                      isFavorite={favoriteIds.includes(item.id)}
                      isActive={activeAudioTrack?.id === item.id || activeVideoItem?.id === item.id}
                      isPlaying={activeAudioTrack?.id === item.id && isAudioPlaying}
                      onPlay={() => handlePlayItem(item)}
                      onToggleFavorite={() => toggleFavorite(item.id)}
                    />
                  ))}
                </div>
              )}
            </section>
          </>
        )}

        {activeTab === 'search' && (
          <section className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-[#E8C668]">
                တရားတော် ရှာဖွေရန်နှင့် ကဏ္ဍများ
              </h2>
              <p className="mt-1 text-sm text-[#CBBBA3]">
                တရားခေါင်းစဉ်၊ ဆရာတော်အမည် သို့မဟုတ် ကဏ္ဍအလိုက် ရှာဖွေနိုင်ပါသည်။
              </p>
            </div>

            <div className="relative">
              <Search className="w-5 h-5 text-[#D4AF37] absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="တရားခေါင်းစဉ်၊ ဆရာတော်အမည် ရိုက်ထည့်ရှာဖွေပါ..."
                className="w-full rounded-2xl bg-[#221811] border border-[#422E1E] pl-12 pr-4 py-3.5 text-sm text-[#F6EFE4] placeholder-[#8F7B64] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {[ALL_CATEGORY_LABEL, ...DHAMMA_CATEGORIES].map((cat) => {
                const count =
                  cat === ALL_CATEGORY_LABEL
                    ? items.length
                    : items.filter((i) => i.category === cat).length;
                const active = selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`p-4 rounded-2xl border text-left transition-colors cursor-pointer ${
                      active
                        ? 'bg-[#2E2117] border-[#D4AF37]'
                        : 'bg-[#221811] border-[#422E1E] hover:border-[#8F6F28]'
                    }`}
                  >
                    <p className={`text-sm font-semibold ${active ? 'text-[#E8C668]' : 'text-[#F6EFE4]'}`}>
                      {cat}
                    </p>
                    <p className="mt-1 text-xs text-[#CBBBA3] tabular-nums">{count} ခု</p>
                  </button>
                );
              })}
            </div>

            {filteredItems.length === 0 ? (
              <p className="py-10 text-center text-sm text-[#CBBBA3]">
                ရှာဖွေမှုနှင့် ကိုက်ညီသော တရားတော် မတွေ့ရှိပါ။
              </p>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {filteredItems.map((item) => (
                  <DhammaCard
                    key={item.id}
                    item={item}
                    isFavorite={favoriteIds.includes(item.id)}
                    isActive={activeAudioTrack?.id === item.id || activeVideoItem?.id === item.id}
                    isPlaying={activeAudioTrack?.id === item.id && isAudioPlaying}
                    onPlay={() => handlePlayItem(item)}
                    onToggleFavorite={() => toggleFavorite(item.id)}
                  />
                ))}
              </div>
            )}
          </section>
        )}

        {activeTab === 'favorites' && (
          <section className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="text-2xl font-bold text-[#E8C668]">
                နှစ်သက်ရာနှင့် မကြာသေးမီက နားထောင်ခဲ့သည်များ
              </h2>

              <div className="flex items-center gap-1 p-1 rounded-xl bg-[#221811] border border-[#422E1E]">
                <button
                  type="button"
                  onClick={() => setFavoritesTabMode('favorites')}
                  className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                    favoritesTabMode === 'favorites'
                      ? 'bg-[#D4AF37] text-[#160F0A]'
                      : 'text-[#CBBBA3] hover:text-[#F6EFE4]'
                  }`}
                >
                  နှစ်သက်ရာ ({favoriteItems.length})
                </button>
                <button
                  type="button"
                  onClick={() => setFavoritesTabMode('recents')}
                  className={`px-4 py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors cursor-pointer ${
                    favoritesTabMode === 'recents'
                      ? 'bg-[#D4AF37] text-[#160F0A]'
                      : 'text-[#CBBBA3] hover:text-[#F6EFE4]'
                  }`}
                >
                  မကြာသေးမီ ({recentItems.length})
                </button>
              </div>
            </div>

            {(() => {
              const list = favoritesTabMode === 'favorites' ? favoriteItems : recentItems;
              if (list.length === 0) {
                return (
                  <p className="py-12 text-center text-sm text-[#CBBBA3]">
                    {favoritesTabMode === 'favorites'
                      ? 'နှစ်သက်ရာ တရားတော်များ မရှိသေးပါ။ နှလုံးသားပုံကို နှိပ်၍ သိမ်းဆည်းနိုင်ပါသည်။'
                      : 'မကြာသေးမီက နားထောင်ခဲ့သော တရားတော်များ မရှိသေးပါ။'}
                  </p>
                );
              }
              return (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  {list.map((item) => (
                    <DhammaCard
                      key={item.id}
                      item={item}
                      isFavorite={favoriteIds.includes(item.id)}
                      isActive={activeAudioTrack?.id === item.id || activeVideoItem?.id === item.id}
                      isPlaying={activeAudioTrack?.id === item.id && isAudioPlaying}
                      onPlay={() => handlePlayItem(item)}
                      onToggleFavorite={() => toggleFavorite(item.id)}
                    />
                  ))}
                </div>
              );
            })()}
          </section>
        )}

        {activeTab === 'android' && <AndroidSourceExplorer />}

        {activeTab === 'admin' && (
          <AdminPanel
            adminStatus={adminStatus}
            items={items}
            onRefreshAdmin={fetchAdminStatus}
            onRefreshItems={fetchItems}
          />
        )}
      </main>

      {/* Mobile Compact Bottom Navigation (<= 15% mobile height) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-14 bg-[#1D140D]/95 backdrop-blur-md border-t border-[#422E1E] grid grid-cols-5 items-center">
        {(
          [
            { id: 'home', label: 'ပင်မ', icon: Home },
            { id: 'search', label: 'ရှာဖွေ', icon: Search },
            { id: 'favorites', label: 'နှစ်သက်', icon: Heart },
            { id: 'android', label: 'ကုဒ်', icon: Code2 },
            { id: 'admin', label: 'စီမံသူ', icon: ShieldCheck },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`h-full flex flex-col items-center justify-center gap-0.5 text-[10px] cursor-pointer ${
                active ? 'text-[#E8C668] font-semibold' : 'text-[#9B856B]'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Persistent MP3 Audio Player */}
      <AudioPlayerBar
        track={activeAudioTrack}
        playNonce={audioPlayNonce}
        isFavorite={activeAudioTrack ? favoriteIds.includes(activeAudioTrack.id) : false}
        buddhaArtworkUrl={BUDDHA_IMAGE}
        onToggleFavorite={toggleFavorite}
        onPlayingStateChange={setIsAudioPlaying}
        onClose={() => {
          setActiveAudioTrack(null);
          setIsAudioPlaying(false);
        }}
      />

      {/* Dedicated MP4 Video Player Modal */}
      <VideoPlayerModal
        videoItem={activeVideoItem}
        isFavorite={activeVideoItem ? favoriteIds.includes(activeVideoItem.id) : false}
        onToggleFavorite={toggleFavorite}
        onClose={() => setActiveVideoItem(null)}
      />
    </div>
  );
}
