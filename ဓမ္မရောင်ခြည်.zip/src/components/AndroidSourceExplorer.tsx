import React, { useEffect, useState } from 'react';
import { Copy, Check, FileCode2 } from 'lucide-react';
import { AndroidSourceFile } from '../types/dhamma';

export const AndroidSourceExplorer: React.FC = () => {
  const [files, setFiles] = useState<AndroidSourceFile[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch('/api/android-files')
      .then((res) => res.json())
      .then((data) => {
        const list: AndroidSourceFile[] = Array.isArray(data.files) ? data.files : [];
        setFiles(list);
        const preferred =
          list.find((f) => f.path === 'ANDROID_APK_BUILD_GUIDE.md') ?? list[0];
        if (preferred) setSelectedPath(preferred.path);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const activeFile = files.find((f) => f.path === selectedPath);

  const handleCopy = async () => {
    if (!activeFile) return;
    await navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="space-y-6">
      <div className="pb-4 border-b border-[#422E1E]">
        <h2 className="text-2xl font-bold text-[#E8C668]">
          Native Android (Kotlin & Jetpack Compose) နှင့် Firebase လမ်းညွှန်
        </h2>
        <p className="mt-1.5 text-sm text-[#CBBBA3]">
          Android Studio တွင် တိုက်ရိုက်တည်ဆောက်နိုင်သော Kotlin, Jetpack Compose, Media3 ExoPlayer, Firestore, Firebase Auth နှင့် Storage Rules ဖိုင်အပြည့်အစုံကို ဤနေရာတွင် ကြည့်ရှုကူးယူနိုင်ပါသည်။
        </p>
      </div>

      {loading ? (
        <p className="text-sm text-[#CBBBA3]">ဖိုင်များ ရယူနေပါသည်...</p>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* File Tree */}
          <div className="lg:col-span-4 rounded-2xl bg-[#221811] border border-[#422E1E] p-3 max-h-[540px] overflow-y-auto space-y-1">
            {files.map((file) => {
              const isSelected = file.path === selectedPath;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedPath(file.path)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-[#D4AF37] text-[#160F0A] font-semibold'
                      : 'text-[#CBBBA3] hover:bg-[#2E2117] hover:text-[#F6EFE4]'
                  }`}
                >
                  <FileCode2 className="w-4 h-4 shrink-0" />
                  <span className="truncate">{file.path}</span>
                </button>
              );
            })}
          </div>

          {/* Code Viewer */}
          <div className="lg:col-span-8 rounded-2xl bg-[#120C08] border border-[#422E1E] overflow-hidden flex flex-col max-h-[540px]">
            <div className="px-4 py-3 bg-[#221811] border-b border-[#422E1E] flex items-center justify-between gap-3">
              <span className="text-xs font-mono text-[#E8C668] truncate">
                {activeFile?.path || ''}
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#2E2117] border border-[#422E1E] text-xs text-[#F6EFE4] hover:border-[#D4AF37] cursor-pointer shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#81C784]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'ကူးယူပြီးပါပြီ' : 'ကူးယူရန်'}</span>
              </button>
            </div>
            <pre className="p-4 text-xs font-mono text-[#E6DDD0] overflow-auto leading-relaxed whitespace-pre-wrap">
              {activeFile?.content || ''}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
