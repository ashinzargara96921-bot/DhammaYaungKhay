import React, { useState } from 'react';
import { Upload, Pencil, Trash2, LogOut, ShieldCheck } from 'lucide-react';
import { AdminStatus, DHAMMA_CATEGORIES, DhammaContent, MediaType } from '../types/dhamma';

interface AdminPanelProps {
  adminStatus: AdminStatus;
  items: DhammaContent[];
  onRefreshAdmin: () => Promise<void>;
  onRefreshItems: () => Promise<void>;
}

const ADMIN_TOKEN_KEY = 'dhamma_admin_token';

function getAuthHeaders(extra?: Record<string, string>): Record<string, string> {
  const token = sessionStorage.getItem(ADMIN_TOKEN_KEY);
  return {
    ...(extra ?? {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  adminStatus,
  items,
  onRefreshAdmin,
  onRefreshItems,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authBusy, setAuthBusy] = useState(false);

  // Upload / Edit Form State
  const [editingItem, setEditingItem] = useState<DhammaContent | null>(null);
  const [title, setTitle] = useState('');
  const [preacher, setPreacher] = useState('');
  const [category, setCategory] = useState<string>(DHAMMA_CATEGORIES[0]);
  const [description, setDescription] = useState('');
  const [mediaType, setMediaType] = useState<MediaType>('MP3');
  const [durationText, setDurationText] = useState('');
  const [externalUrl, setExternalUrl] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadBusy, setUploadBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthBusy(true);
    try {
      const endpoint = adminStatus.isConfigured ? '/api/admin/login' : '/api/admin/setup';
      const res = await fetch(endpoint, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
      });

      let data: { ok?: boolean; token?: string; error?: string } = {};
      try {
        data = await res.json();
      } catch {
        setAuthError('ဆာဗာမှ တုံ့ပြန်ချက် ဖတ်ရှုရာတွင် အမှားဖြစ်ပွားပါသည်');
        return;
      }

      if (!res.ok || !data.ok) {
        setAuthError(data.error || 'အီးမေးလ် သို့မဟုတ် စကားဝှက် မှားယွင်းနေပါသည်');
        return;
      }

      if (data.token) {
        sessionStorage.setItem(ADMIN_TOKEN_KEY, data.token);
      }

      // Verify the session is actually accepted before clearing inputs
      const verifyRes = await fetch('/api/admin/status', {
        credentials: 'include',
        headers: getAuthHeaders(),
      });
      const verifyData = await verifyRes.json();

      if (!verifyRes.ok || !verifyData.isAuthenticated) {
        sessionStorage.removeItem(ADMIN_TOKEN_KEY);
        setAuthError('အကောင့်စစ်ဆေးပြီးသော်လည်း Session သိမ်းဆည်း၍မရပါ။ ထပ်မံကြိုးစားပါ။');
        return;
      }

      setEmail('');
      setPassword('');
      await onRefreshAdmin();
    } catch {
      setAuthError('ဆာဗာနှင့် ချိတ်ဆက်၍ မရပါ။ ကွန်ရက်ချိတ်ဆက်မှုကို စစ်ဆေးပါ။');
    } finally {
      setAuthBusy(false);
    }
  };

  const handleLogout = async () => {
    sessionStorage.removeItem(ADMIN_TOKEN_KEY);
    await fetch('/api/admin/logout', {
      method: 'POST',
      credentials: 'include',
    });
    await onRefreshAdmin();
  };

  const resetForm = () => {
    setEditingItem(null);
    setTitle('');
    setPreacher('');
    setCategory(DHAMMA_CATEGORIES[0]);
    setDescription('');
    setMediaType('MP3');
    setDurationText('');
    setExternalUrl('');
    setSelectedFile(null);
  };

  const startEdit = (item: DhammaContent) => {
    setEditingItem(item);
    setTitle(item.title);
    setPreacher(item.preacher);
    setCategory(item.category);
    setDescription(item.description);
    setMediaType(item.mediaType);
    setDurationText(item.durationText);
    setFeedback(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setUploadBusy(true);

    try {
      if (editingItem) {
        const res = await fetch(`/api/admin/dhamma/${editingItem.id}`, {
          method: 'PUT',
          credentials: 'include',
          headers: getAuthHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            title,
            preacher,
            category,
            description,
            mediaType,
            durationText,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          setFeedback({ ok: false, text: data.error || 'ပြင်ဆင်မှု မအောင်မြင်ပါ' });
          if (res.status === 401) await onRefreshAdmin();
        } else {
          setFeedback({ ok: true, text: 'တရားတော် အချက်အလက် ပြင်ဆင်ပြီးပါပြီ' });
          resetForm();
          await onRefreshItems();
        }
      } else {
        const formData = new FormData();
        formData.append('title', title);
        formData.append('preacher', preacher);
        formData.append('category', category);
        formData.append('description', description);
        formData.append('mediaType', mediaType);
        formData.append('durationText', durationText || '00:00');
        if (externalUrl.trim()) {
          formData.append('externalUrl', externalUrl.trim());
        }
        if (selectedFile) {
          formData.append('mediaFile', selectedFile);
        }

        const res = await fetch('/api/admin/dhamma', {
          method: 'POST',
          credentials: 'include',
          headers: getAuthHeaders(),
          body: formData,
        });
        const data = await res.json();
        if (!res.ok) {
          setFeedback({ ok: false, text: data.error || 'တင်သွင်းမှု မအောင်မြင်ပါ' });
          if (res.status === 401) await onRefreshAdmin();
        } else {
          setFeedback({ ok: true, text: 'တရားတော်အသစ် တင်သွင်းပြီးပါပြီ' });
          resetForm();
          await onRefreshItems();
        }
      }
    } catch {
      setFeedback({ ok: false, text: 'တင်သွင်းရာတွင် ချိတ်ဆက်မှု အမှားဖြစ်ပွားပါသည်' });
    } finally {
      setUploadBusy(false);
    }
  };

  const handleDelete = async (item: DhammaContent) => {
    setFeedback(null);
    const res = await fetch(`/api/admin/dhamma/${item.id}`, {
      method: 'DELETE',
      credentials: 'include',
      headers: getAuthHeaders(),
    });
    if (res.ok) {
      setFeedback({ ok: true, text: `"${item.title}" ကို ဖျက်သိမ်းပြီးပါပြီ` });
      if (editingItem?.id === item.id) resetForm();
      await onRefreshItems();
    } else {
      const data = await res.json().catch(() => ({}));
      setFeedback({ ok: false, text: data.error || 'ဖျက်သိမ်းမှု မအောင်မြင်ပါ' });
      if (res.status === 401) await onRefreshAdmin();
    }
  };

  if (!adminStatus.isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-8 rounded-2xl bg-[#221811] border border-[#422E1E] p-6 sm:p-8">
        <div className="flex items-center gap-3 text-[#E8C668]">
          <ShieldCheck className="w-6 h-6 shrink-0" />
          <h2 className="text-xl font-bold">
            {adminStatus.isConfigured
              ? 'စီမံခန့်ခွဲသူ (Admin) ဝင်ရောက်ရန်'
              : 'စီမံခန့်ခွဲသူ အကောင့် သတ်မှတ်ရန်'}
          </h2>
        </div>

        <p className="mt-2.5 text-sm text-[#CBBBA3] leading-relaxed">
          {adminStatus.isConfigured
            ? 'သာမန်အသုံးပြုသူများ အကောင့်ဝင်ရန် မလိုအပ်ပါ။ MP3 နှင့် MP4 တရားတော်များ တင်သွင်း၊ ပြင်ဆင်၊ ဖျက်သိမ်းရန်အတွက်သာ စီမံသူ ဝင်ရောက်ရပါမည်။'
            : 'ပထမဆုံးအကြိမ် စီမံခန့်ခွဲသူ အီးမေးလ်နှင့် စကားဝှက် သတ်မှတ်ပါ။'}
        </p>

        {adminStatus.envStatus &&
          (!adminStatus.envStatus.hasAdminEmail || !adminStatus.envStatus.hasAdminPassword) && (
            <p className="mt-3 text-xs text-[#CBBBA3] rounded-xl bg-[#160F0A] border border-[#422E1E] px-3.5 py-2.5 leading-relaxed">
              {adminStatus.authSource === 'local_file'
                ? 'ဆာဗာ Environment Variables (ADMIN_EMAIL / ADMIN_PASSWORD) မတွေ့ရှိသေးပါ — လက်ရှိတွင် စက်အတွင်း သိမ်းဆည်းထားသော စီမံသူအကောင့်ဖြင့် စစ်ဆေးနေပါသည်။'
                : 'ဆာဗာ Environment Variables (ADMIN_EMAIL / ADMIN_PASSWORD) မတွေ့ရှိသေးပါ။'}
            </p>
          )}

        <form onSubmit={handleAuthSubmit} className="mt-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              အီးမေးလ် (Email)
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@example.com"
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-3 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              စကားဝှက် (Password)
            </label>
            <input
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-3 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          {authError && (
            <p
              className="text-sm text-[#F5A3A3] rounded-xl bg-[#3A1818] border border-[#7F3232] px-3.5 py-2.5"
              role="alert"
            >
              {authError}
            </p>
          )}

          <button
            type="submit"
            disabled={authBusy}
            className="w-full min-h-[46px] rounded-xl bg-[#D4AF37] text-[#160F0A] font-semibold text-sm hover:bg-[#E8C668] transition-colors disabled:opacity-60 cursor-pointer"
          >
            {authBusy
              ? 'စစ်ဆေးနေပါသည်...'
              : adminStatus.isConfigured
              ? 'အကောင့်ဝင်ရန်'
              : 'စီမံသူအကောင့် ဖန်တီးရန်'}
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#422E1E]">
        <div>
          <h2 className="text-2xl font-bold text-[#E8C668]">စီမံခန့်ခွဲမှု စင်တာ</h2>
          <p className="mt-1 text-sm text-[#CBBBA3]">
            ဝင်ရောက်ထားသူ — {adminStatus.email}
          </p>
        </div>
        <button
          type="button"
          onClick={handleLogout}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl border border-[#422E1E] text-sm text-[#F6EFE4] hover:border-[#D4AF37] hover:text-[#E8C668] transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>ထွက်ရန်</span>
        </button>
      </div>

      {/* Upload / Edit Form */}
      <form
        onSubmit={handleFormSubmit}
        className="rounded-2xl bg-[#221811] border border-[#422E1E] p-5 sm:p-6 space-y-5"
      >
        <h3 className="text-lg font-semibold text-[#F6EFE4]">
          {editingItem ? 'တရားတော် အချက်အလက် ပြင်ဆင်ရန်' : 'တရားတော်အသစ် (MP3 / MP4) တင်သွင်းရန်'}
        </h3>

        <div className="flex items-center gap-2">
          {(['MP3', 'MP4'] as MediaType[]).map((type) => (
            <button
              key={type}
              type="button"
              onClick={() => setMediaType(type)}
              className={`px-4 py-2 rounded-xl text-sm font-medium border transition-colors cursor-pointer ${
                mediaType === type
                  ? 'bg-[#D4AF37] text-[#160F0A] border-[#D4AF37]'
                  : 'bg-[#160F0A] text-[#CBBBA3] border-[#422E1E] hover:border-[#8F6F28]'
              }`}
            >
              {type === 'MP3' ? 'MP3 အသံတော်' : 'MP4 ဗီဒီယို'}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              တရားခေါင်းစဉ် *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ဥပမာ - မေတ္တာသုတ် တရားတော်"
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-2.5 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              ဟောကြားသူ ဆရာတော် / ရွတ်ဖတ်သူ *
            </label>
            <input
              type="text"
              required
              value={preacher}
              onChange={(e) => setPreacher(e.target.value)}
              placeholder="ဥပမာ - မဟာစည်ဆရာတော်ဘုရားကြီး"
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-2.5 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              ကဏ္ဍ (Category)
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-2.5 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
            >
              {DHAMMA_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
              ကြာချိန်
            </label>
            <input
              type="text"
              value={durationText}
              onChange={(e) => setDurationText(e.target.value)}
              placeholder="ဥပမာ - 45:20"
              className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-2.5 text-sm text-[#F6EFE4] tabular-nums focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
            အကြောင်းအရာ အကျဉ်း
          </label>
          <textarea
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="တရားတော်အကြောင်း အကျဉ်းချုပ် ရေးသားပါ..."
            className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-2.5 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
          />
        </div>

        {!editingItem && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
                {mediaType === 'MP3' ? 'MP3 ဖိုင် ရွေးချယ်တင်သွင်းရန်' : 'MP4 ဖိုင် ရွေးချယ်တင်သွင်းရန်'}
              </label>
              <label className="flex items-center justify-center gap-2 rounded-xl border border-dashed border-[#8F6F28] bg-[#160F0A] px-4 py-3 text-sm text-[#E8C668] hover:border-[#D4AF37] cursor-pointer">
                <Upload className="w-4 h-4" />
                <span className="truncate">
                  {selectedFile ? selectedFile.name : 'စက်ထဲမှ ဖိုင်ရွေးချယ်ရန်'}
                </span>
                <input
                  type="file"
                  accept={mediaType === 'MP3' ? 'audio/*,.mp3' : 'video/*,.mp4'}
                  onChange={(e) => setSelectedFile(e.target.files?.[0] ?? null)}
                  className="hidden"
                />
              </label>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#CBBBA3] mb-1.5">
                သို့မဟုတ် တိုက်ရိုက် Media URL (Optional)
              </label>
              <input
                type="url"
                value={externalUrl}
                onChange={(e) => setExternalUrl(e.target.value)}
                placeholder="https://..."
                className="w-full rounded-xl bg-[#160F0A] border border-[#422E1E] px-4 py-3 text-sm text-[#F6EFE4] focus:outline-none focus:border-[#D4AF37]"
              />
            </div>
          </div>
        )}

        {feedback && (
          <p className={`text-sm ${feedback.ok ? 'text-[#81C784]' : 'text-[#E57373]'}`}>
            {feedback.text}
          </p>
        )}

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={uploadBusy}
            className="px-6 py-2.5 rounded-xl bg-[#D4AF37] text-[#160F0A] font-semibold text-sm hover:bg-[#E8C668] transition-colors disabled:opacity-60 cursor-pointer"
          >
            {uploadBusy
              ? 'ဆောင်ရွက်နေပါသည်...'
              : editingItem
              ? 'ပြင်ဆင်မှု သိမ်းဆည်းရန်'
              : 'တရားတော် တင်သွင်းရန်'}
          </button>

          {editingItem && (
            <button
              type="button"
              onClick={resetForm}
              className="px-5 py-2.5 rounded-xl border border-[#422E1E] text-sm text-[#CBBBA3] hover:text-[#F6EFE4] cursor-pointer"
            >
              မလုပ်တော့ပါ
            </button>
          )}
        </div>
      </form>

      {/* Existing Items Table / List */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold text-[#F6EFE4]">
          တင်သွင်းပြီးသော တရားတော်များ ({items.length})
        </h3>

        {items.length === 0 ? (
          <p className="text-sm text-[#9B856B] py-4">
            တင်သွင်းထားသော တရားတော် မရှိသေးပါ။ အထက်ပါပုံစံမှတစ်ဆင့် MP3 / MP4 တင်သွင်းနိုင်ပါသည်။
          </p>
        ) : (
          <div className="divide-y divide-[#422E1E] rounded-2xl border border-[#422E1E] bg-[#221811] overflow-hidden">
            {items.map((item) => (
              <div
                key={item.id}
                className="p-4 flex items-center justify-between gap-4 hover:bg-[#2B1F16] transition-colors"
              >
                <div className="min-w-0">
                  <p className="text-sm sm:text-base font-medium text-[#F6EFE4] truncate">
                    {item.title}
                  </p>
                  <p className="text-xs text-[#CBBBA3] mt-0.5">
                    {item.preacher} · {item.category} · {item.mediaType} ·{' '}
                    <span className="tabular-nums">{item.durationText}</span>
                  </p>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => startEdit(item)}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-[#D4AF37] hover:bg-[#35261A] cursor-pointer"
                    aria-label="ပြင်ဆင်ရန်"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(item)}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-[#E57373] hover:bg-[#35261A] cursor-pointer"
                    aria-label="ဖျက်သိမ်းရန်"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
