import React from 'react';
import { AudioLines, Video, Heart, Play, Pause } from 'lucide-react';
import { DhammaContent } from '../types/dhamma';

interface DhammaCardProps {
  item: DhammaContent;
  isFavorite: boolean;
  isPlaying: boolean;
  isActive: boolean;
  onPlay: () => void;
  onToggleFavorite: () => void;
}

export const DhammaCard: React.FC<DhammaCardProps> = ({
  item,
  isFavorite,
  isPlaying,
  isActive,
  onPlay,
  onToggleFavorite,
}) => {
  const isAudio = item.mediaType === 'MP3';

  return (
    <article
      className={`group relative rounded-2xl border transition-colors duration-150 ${
        isActive
          ? 'bg-[#2B1F16] border-[#D4AF37]'
          : 'bg-[#221811] border-[#422E1E] hover:border-[#8F6F28]'
      }`}
    >
      <div className="p-4 sm:p-5 flex items-center gap-4">
        {/* Media Type Icon */}
        <button
          type="button"
          onClick={onPlay}
          aria-label={`${item.title} ဖွင့်ရန်`}
          className="relative shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-[#35261A] to-[#160F0A] border border-[#422E1E] flex items-center justify-center text-[#D4AF37] hover:border-[#D4AF37] transition-colors cursor-pointer min-h-[44px] min-w-[44px]"
        >
          {isAudio ? <AudioLines className="w-6 h-6" /> : <Video className="w-6 h-6" />}
        </button>

        {/* Unboxed Burmese Content & Clean Metadata */}
        <div className="min-w-0 flex-1">
          <button
            type="button"
            onClick={onPlay}
            className="text-left w-full cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#D4AF37] rounded"
          >
            <h3
              className={`text-base sm:text-lg font-semibold leading-snug line-clamp-2 ${
                isActive ? 'text-[#E8C668]' : 'text-[#F6EFE4] group-hover:text-[#E8C668]'
              } transition-colors`}
            >
              {item.title}
            </h3>
          </button>

          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs sm:text-sm text-[#CBBBA3]">
            <span className="truncate max-w-[220px]">{item.preacher}</span>
            <span aria-hidden="true">·</span>
            <span>{item.category}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums text-[#9B856B]">
              {isAudio ? 'MP3 အသံ' : 'MP4 ဗီဒီယို'} · {item.durationText}
            </span>
          </div>

          {item.description && (
            <p className="mt-1.5 text-xs text-[#9B856B] line-clamp-1">
              {item.description}
            </p>
          )}
        </div>

        {/* Touch-friendly Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={onToggleFavorite}
            aria-label={isFavorite ? 'နှစ်သက်ရာမှ ဖယ်ရှားရန်' : 'နှစ်သက်ရာသို့ ထည့်ရန်'}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#E8C668] hover:bg-[#35261A] transition-colors cursor-pointer"
          >
            <Heart
              className={`w-5 h-5 ${
                isFavorite ? 'fill-[#D4AF37] text-[#D4AF37]' : ''
              }`}
            />
          </button>

          <button
            type="button"
            onClick={onPlay}
            aria-label={isPlaying ? 'ခေတ္တရပ်ရန်' : 'ဖွင့်ရန်'}
            className={`min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full transition-colors cursor-pointer ${
              isActive
                ? 'bg-[#D4AF37] text-[#160F0A]'
                : 'bg-[#35261A] text-[#E8C668] hover:bg-[#D4AF37] hover:text-[#160F0A]'
            }`}
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
          </button>
        </div>
      </div>
    </article>
  );
};
