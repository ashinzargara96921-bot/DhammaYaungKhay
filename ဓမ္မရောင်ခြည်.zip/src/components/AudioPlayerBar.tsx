import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  ChevronUp,
  ChevronDown,
  Heart,
  AudioLines,
  X,
} from 'lucide-react';
import { DhammaContent } from '../types/dhamma';

interface AudioPlayerBarProps {
  track: DhammaContent | null;
  playNonce: number;
  isFavorite: boolean;
  buddhaArtworkUrl: string;
  onToggleFavorite: (id: string) => void;
  onPlayingStateChange: (isPlaying: boolean) => void;
  onClose: () => void;
}

function formatSeconds(sec: number): string {
  if (!Number.isFinite(sec) || sec < 0) return '00:00';
  const total = Math.floor(sec);
  const hrs = Math.floor(total / 3600);
  const mins = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  if (hrs > 0) {
    return `${hrs}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  track,
  playNonce,
  isFavorite,
  buddhaArtworkUrl,
  onToggleFavorite,
  onPlayingStateChange,
  onClose,
}) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const blobUrlRef = useRef<string | null>(null);
  const fallbackAttemptedRef = useRef(false);

  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [speed, setSpeed] = useState(1);
  const [expanded, setExpanded] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  const revokeBlobUrl = () => {
    if (blobUrlRef.current) {
      URL.revokeObjectURL(blobUrlRef.current);
      blobUrlRef.current = null;
    }
  };

  const startPlay = async (audio: HTMLAudioElement) => {
    try {
      audio.playbackRate = speed;
      await audio.play();
      setAudioError(null);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'NotAllowedError') {
        setAudioError('အသံဖွင့်ရန် Play ခလုတ်ကို နှိပ်ပါ');
      }
      setIsPlaying(false);
      onPlayingStateChange(false);
    }
  };

  const loadAuthenticatedBlobFallback = async (mediaUrl: string) => {
    const audio = audioRef.current;
    if (!audio || fallbackAttemptedRef.current) return;
    fallbackAttemptedRef.current = true;
    setIsLoadingAudio(true);
    setAudioError(null);

    try {
      const res = await fetch(mediaUrl, { credentials: 'include' });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok) {
        setAudioError(`MP3 ဖိုင် ရယူ၍မရပါ (HTTP ${res.status})`);
        return;
      }
      if (contentType.includes('text/html')) {
        setAudioError('မီဒီယာဖိုင်အစား HTML စာမျက်နှာ ပြန်လာနေပါသည် — စာမျက်နှာကို Reload လုပ်ပြီး ထပ်စမ်းပါ');
        return;
      }
      const rawBlob = await res.blob();
      if (rawBlob.size === 0) {
        setAudioError('MP3 ဖိုင်အရွယ်အစား ၀ ဖြစ်နေပါသည်');
        return;
      }
      const typedBlob =
        rawBlob.type && rawBlob.type.startsWith('audio/')
          ? rawBlob
          : new Blob([rawBlob], { type: 'audio/mpeg' });
      revokeBlobUrl();
      const objUrl = URL.createObjectURL(typedBlob);
      blobUrlRef.current = objUrl;
      audio.src = objUrl;
      audio.load();
      await startPlay(audio);
    } catch {
      setAudioError('MP3 အသံဖိုင် တင်ယူရာတွင် ကွန်ရက်အမှား ဖြစ်ပွားပါသည်');
    } finally {
      setIsLoadingAudio(false);
    }
  };

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !track) {
      revokeBlobUrl();
      return;
    }

    // Same track clicked again -> toggle play/pause cleanly
    if (audio.dataset.trackId === track.id && audio.src) {
      if (audio.paused) {
        void startPlay(audio);
      } else {
        audio.pause();
      }
      return;
    }

    revokeBlobUrl();
    fallbackAttemptedRef.current = false;
    audio.dataset.trackId = track.id;
    setAudioError(null);
    setCurrentTime(0);
    setDuration(0);
    setIsLoadingAudio(true);

    audio.src = track.mediaUrl;
    audio.load();
    void startPlay(audio).finally(() => {
      setIsLoadingAudio(false);
    });
  }, [track?.id, track?.mediaUrl, playNonce]);

  useEffect(() => {
    return () => {
      revokeBlobUrl();
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  }, [speed]);

  // Guaranteed timer sync while audio is playing
  useEffect(() => {
    if (!isPlaying) return;
    const timer = window.setInterval(() => {
      const audio = audioRef.current;
      if (audio && !audio.paused) {
        setCurrentTime(audio.currentTime || 0);
        if (Number.isFinite(audio.duration) && audio.duration > 0) {
          setDuration(audio.duration);
        }
      }
    }, 250);
    return () => window.clearInterval(timer);
  }, [isPlaying]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !track) return;
    if (audio.paused) {
      if (audio.error && !fallbackAttemptedRef.current) {
        void loadAuthenticatedBlobFallback(track.mediaUrl);
      } else {
        void startPlay(audio);
      }
    } else {
      audio.pause();
    }
  };

  const seekTo = (val: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = val;
    setCurrentTime(val);
  };

  const skipBy = (delta: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const maxDur = Number.isFinite(duration) && duration > 0 ? duration : audio.duration || 0;
    const next = Math.max(0, Math.min(maxDur, audio.currentTime + delta));
    audio.currentTime = next;
    setCurrentTime(next);
  };

  const progressPct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <>
      <audio
        ref={audioRef}
        preload="metadata"
        playsInline
        onPlay={() => {
          setIsPlaying(true);
          setAudioError(null);
          onPlayingStateChange(true);
        }}
        onPause={() => {
          setIsPlaying(false);
          onPlayingStateChange(false);
        }}
        onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime || 0)}
        onLoadedMetadata={(e) => {
          setIsLoadingAudio(false);
          if (Number.isFinite(e.currentTarget.duration)) {
            setDuration(e.currentTarget.duration);
          }
        }}
        onDurationChange={(e) => {
          if (Number.isFinite(e.currentTarget.duration)) {
            setDuration(e.currentTarget.duration);
          }
        }}
        onCanPlay={() => setIsLoadingAudio(false)}
        onEnded={() => {
          setIsPlaying(false);
          onPlayingStateChange(false);
        }}
        onError={() => {
          if (!track) return;
          setIsPlaying(false);
          onPlayingStateChange(false);
          if (!fallbackAttemptedRef.current && track.mediaUrl.startsWith('/api/media/')) {
            void loadAuthenticatedBlobFallback(track.mediaUrl);
            return;
          }
          setIsLoadingAudio(false);
          setAudioError('MP3 အသံဖိုင် ဖွင့်၍မရပါ။ ဖိုင်ပုံစံ သို့မဟုတ် လင့်ခ်ကို စစ်ဆေးပါ။');
        }}
      />

      {track && (
        <>
          {/* Full Expanded Burmese Audio Player Modal */}
          {expanded && (
        <div className="fixed inset-0 z-50 bg-[#160F0A]/98 backdrop-blur-lg flex flex-col justify-between p-5 sm:p-8">
          <div className="max-w-2xl w-full mx-auto flex items-center justify-between">
            <button
              type="button"
              onClick={() => setExpanded(false)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#E8C668] hover:bg-[#221811] cursor-pointer"
              aria-label="လျှော့ချရန်"
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <span className="text-sm font-medium text-[#CBBBA3]">
              MP3 တရားတော် နားဆင်ခြင်း
            </span>
            <button
              type="button"
              onClick={() => onToggleFavorite(track.id)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#E8C668] hover:bg-[#221811] cursor-pointer"
              aria-label="နှစ်သက်ရာ"
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#D4AF37] text-[#D4AF37]' : ''}`} />
            </button>
          </div>

          <div className="max-w-xl w-full mx-auto flex flex-col items-center text-center my-auto">
            <div className="w-56 h-56 sm:w-72 sm:h-72 rounded-3xl overflow-hidden border border-[#D4AF37]/40 shadow-2xl shadow-black/60 bg-[#221811]">
              <img
                src={buddhaArtworkUrl}
                alt={track.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            <h2 className="mt-6 text-xl sm:text-2xl font-bold text-[#E8C668] text-balance">
              {track.title}
            </h2>
            <p className="mt-1.5 text-sm sm:text-base text-[#CBBBA3]">
              {track.preacher} · {track.category}
            </p>

            {isLoadingAudio && !audioError && (
              <p className="mt-3 text-xs text-[#E8C668]">အသံဖိုင် တင်ယူနေပါသည်...</p>
            )}

            {audioError && (
              <p className="mt-3 text-sm text-[#F5A3A3]" role="alert">
                {audioError}
              </p>
            )}

            {/* Seek Slider */}
            <div className="w-full mt-7">
              <input
                type="range"
                min={0}
                max={duration > 0 ? duration : 100}
                step={0.1}
                value={currentTime}
                onChange={(e) => seekTo(Number(e.target.value))}
                className="w-full accent-[#D4AF37] cursor-pointer"
                aria-label="အသံအချိန် ရွှေ့ရန်"
              />
              <div className="mt-1.5 flex justify-between text-xs text-[#9B856B] tabular-nums">
                <span>{formatSeconds(currentTime)}</span>
                <span>{duration > 0 ? formatSeconds(duration) : track.durationText}</span>
              </div>
            </div>

            {/* Playback Controls */}
            <div className="mt-6 flex items-center justify-center gap-6">
              <button
                type="button"
                onClick={() => skipBy(-15)}
                className="min-h-[48px] min-w-[48px] flex flex-col items-center justify-center rounded-full text-[#F6EFE4] hover:text-[#E8C668] hover:bg-[#221811] cursor-pointer"
                aria-label="၁၅ စက္ကန့် နောက်ဆုတ်"
              >
                <RotateCcw className="w-6 h-6" />
                <span className="text-[10px] tabular-nums mt-0.5">15s</span>
              </button>

              <button
                type="button"
                onClick={togglePlay}
                className="w-16 h-16 rounded-full bg-[#D4AF37] text-[#160F0A] hover:bg-[#E8C668] flex items-center justify-center shadow-lg transition-transform active:scale-95 cursor-pointer"
                aria-label={isPlaying ? 'ခေတ္တရပ်ရန်' : 'ဖွင့်ရန်'}
              >
                {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7 ml-0.5" />}
              </button>

              <button
                type="button"
                onClick={() => skipBy(15)}
                className="min-h-[48px] min-w-[48px] flex flex-col items-center justify-center rounded-full text-[#F6EFE4] hover:text-[#E8C668] hover:bg-[#221811] cursor-pointer"
                aria-label="၁၅ စက္ကန့် ရှေ့တိုး"
              >
                <RotateCw className="w-6 h-6" />
                <span className="text-[10px] tabular-nums mt-0.5">15s</span>
              </button>
            </div>

            {/* Playback Speed */}
            <div className="mt-6 flex items-center gap-2">
              {[0.75, 1, 1.25, 1.5].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => setSpeed(rate)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium tabular-nums border transition-colors cursor-pointer ${
                    speed === rate
                      ? 'bg-[#35261A] border-[#D4AF37] text-[#E8C668]'
                      : 'bg-transparent border-[#422E1E] text-[#CBBBA3] hover:border-[#8F6F28]'
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>
          </div>

          <div className="h-4" />
        </div>
      )}

      {/* Compact Sticky Mini Player */}
      <div className="fixed bottom-16 md:bottom-4 left-3 right-3 md:left-auto md:right-6 md:w-[440px] z-40 rounded-2xl bg-[#261A11]/95 backdrop-blur-md border border-[#D4AF37]/50 shadow-2xl overflow-hidden">
        {audioError && (
          <div className="px-4 py-1.5 bg-[#3A1818] border-b border-[#7F3232] text-xs text-[#F5A3A3]">
            {audioError}
          </div>
        )}

        <div className="px-4 py-2.5 flex items-center gap-3">
          <button
            type="button"
            onClick={() => setExpanded(true)}
            className="flex items-center gap-3 min-w-0 flex-1 text-left cursor-pointer"
          >
            <div className="w-10 h-10 rounded-xl bg-[#35261A] border border-[#422E1E] flex items-center justify-center text-[#D4AF37] shrink-0">
              <AudioLines className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold text-[#F6EFE4] truncate">{track.title}</p>
              <p className="text-xs text-[#CBBBA3] truncate">
                {track.preacher} ·{' '}
                <span className="tabular-nums">
                  {formatSeconds(currentTime)} / {duration > 0 ? formatSeconds(duration) : track.durationText}
                </span>
              </p>
            </div>
          </button>

          <button
            type="button"
            onClick={togglePlay}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full bg-[#D4AF37] text-[#160F0A] hover:bg-[#E8C668] shrink-0 cursor-pointer"
            aria-label={isPlaying ? 'ခေတ္တရပ်ရန်' : 'ဖွင့်ရန်'}
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
          </button>

          <button
            type="button"
            onClick={() => setExpanded(true)}
            className="min-h-[44px] min-w-[44px] hidden sm:flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#E8C668] cursor-pointer"
            aria-label="အပြည့်အစုံ ဖွင့်ရန်"
          >
            <ChevronUp className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => {
              if (audioRef.current) {
                audioRef.current.pause();
                audioRef.current.removeAttribute('src');
                delete audioRef.current.dataset.trackId;
              }
              revokeBlobUrl();
              onPlayingStateChange(false);
              onClose();
            }}
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#9B856B] hover:text-[#F6EFE4] cursor-pointer"
            aria-label="ပိတ်ရန်"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="h-1 w-full bg-[#422E1E]">
          <div
            className="h-full bg-[#D4AF37] transition-all duration-150"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>
        </>
      )}
    </>
  );
};
