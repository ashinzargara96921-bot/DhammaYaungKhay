import React, { useEffect, useRef, useState } from 'react';
import { X, Heart } from 'lucide-react';
import { DhammaContent } from '../types/dhamma';

interface VideoPlayerModalProps {
  videoItem: DhammaContent | null;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onClose: () => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  videoItem,
  isFavorite,
  onToggleFavorite,
  onClose,
}) => {
  const [resolvedSrc, setResolvedSrc] = useState<string>('');
  const [videoError, setVideoError] = useState<string | null>(null);
  const [isLoadingFallback, setIsLoadingFallback] = useState(false);
  const blobUrlRef = useRef<string | null>(null);
  const fallbackAttemptedRef = useRef(false);

  const revokeBlob = () => {
    if (blobUrlRef.current) {
      URL.revokeObjectURL(blobUrlRef.current);
      blobUrlRef.current = null;
    }
  };

  useEffect(() => {
    revokeBlob();
    fallbackAttemptedRef.current = false;
    setVideoError(null);
    setIsLoadingFallback(false);
    setResolvedSrc(videoItem?.mediaUrl || '');
    return () => revokeBlob();
  }, [videoItem?.id, videoItem?.mediaUrl]);

  if (!videoItem) return null;

  const tryAuthenticatedBlobFallback = async () => {
    if (fallbackAttemptedRef.current || !videoItem.mediaUrl) return;
    fallbackAttemptedRef.current = true;
    setIsLoadingFallback(true);
    setVideoError(null);

    try {
      const res = await fetch(videoItem.mediaUrl, { credentials: 'include' });
      const contentType = res.headers.get('content-type') || '';
      if (!res.ok) {
        setVideoError(
          res.status === 404
            ? 'MP4 ဗီဒီယိုဖိုင်ကို ဆာဗာတွင် မတွေ့ရှိပါ (404)'
            : `MP4 ဗီဒီယိုဖိုင် ရယူ၍မရပါ (HTTP ${res.status})`
        );
        return;
      }
      if (contentType.includes('text/html')) {
        setVideoError('ဗီဒီယိုဖိုင်အစား HTML စာမျက်နှာ ပြန်လာနေပါသည် — စာမျက်နှာကို Reload လုပ်ပြီး ထပ်စမ်းပါ');
        return;
      }
      const rawBlob = await res.blob();
      if (rawBlob.size === 0) {
        setVideoError('MP4 ဗီဒီယိုဖိုင် အရွယ်အစား ၀ ဖြစ်နေပါသည်');
        return;
      }
      const typedBlob =
        rawBlob.type && rawBlob.type.startsWith('video/')
          ? rawBlob
          : new Blob([rawBlob], { type: 'video/mp4' });
      revokeBlob();
      const objUrl = URL.createObjectURL(typedBlob);
      blobUrlRef.current = objUrl;
      setResolvedSrc(objUrl);
    } catch {
      setVideoError('ဗီဒီယိုဖိုင် တင်ယူရာတွင် ကွန်ရက်အမှား ဖြစ်ပွားပါသည်');
    } finally {
      setIsLoadingFallback(false);
    }
  };

  const handleVideoElementError = (e: React.SyntheticEvent<HTMLVideoElement>) => {
    const mediaError = e.currentTarget.error;
    if (!fallbackAttemptedRef.current && videoItem.mediaUrl.startsWith('/api/media/')) {
      void tryAuthenticatedBlobFallback();
      return;
    }

    if (mediaError?.code === MediaError.MEDIA_ERR_NETWORK) {
      setVideoError('ကွန်ရက်ချိတ်ဆက်မှု အခက်အခဲကြောင့် ဗီဒီယို ဖွင့်၍မရပါ');
    } else if (mediaError?.code === MediaError.MEDIA_ERR_DECODE) {
      setVideoError('MP4 ဗီဒီယို Codec ကို ဤ Browser မှ ဖတ်ရှု၍မရပါ (H.264/AAC MP4 ဖြစ်ရန် လိုအပ်ပါသည်)');
    } else {
      setVideoError('ဗီဒီယိုဖိုင် ဖွင့်၍မရပါ။ ဖိုင်လင့်ခ် သို့မဟုတ် MP4 ပုံစံကို စစ်ဆေးပါ။');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="w-full max-w-4xl rounded-2xl bg-[#1D140D] border border-[#422E1E] overflow-hidden shadow-2xl">
        {/* Top Modal Bar */}
        <div className="px-5 py-3.5 border-b border-[#422E1E] flex items-center justify-between gap-4">
          <div className="min-w-0">
            <h2 className="text-base sm:text-lg font-semibold text-[#E8C668] truncate">
              {videoItem.title}
            </h2>
            <p className="text-xs text-[#CBBBA3] truncate">
              {videoItem.preacher} · {videoItem.category}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onToggleFavorite(videoItem.id)}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#E8C668] hover:bg-[#2E2117] cursor-pointer"
              aria-label="နှစ်သက်ရာ"
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#D4AF37] text-[#D4AF37]' : ''}`} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-full text-[#CBBBA3] hover:text-[#F6EFE4] hover:bg-[#2E2117] cursor-pointer"
              aria-label="ပိတ်ရန်"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MP4 Video Frame */}
        <div className="bg-black aspect-video w-full flex items-center justify-center relative">
          {isLoadingFallback ? (
            <div className="p-6 text-center text-sm text-[#E8C668]">
              MP4 ဗီဒီယိုဖိုင်ကို တင်ယူနေပါသည်...
            </div>
          ) : videoError ? (
            <div className="p-6 text-center text-sm text-[#F5A3A3]" role="alert">
              {videoError}
            </div>
          ) : resolvedSrc ? (
            <video
              key={resolvedSrc}
              src={resolvedSrc}
              controls
              autoPlay
              playsInline
              preload="auto"
              onError={handleVideoElementError}
              className="w-full h-full object-contain"
            />
          ) : null}
        </div>

        {/* Description */}
        {videoItem.description && (
          <div className="px-5 py-4 border-t border-[#422E1E]">
            <p className="text-sm text-[#CBBBA3] leading-relaxed">
              {videoItem.description}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
