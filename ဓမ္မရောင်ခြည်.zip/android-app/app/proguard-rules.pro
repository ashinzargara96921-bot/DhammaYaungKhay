# Keep Media3 / ExoPlayer & OkHttp classes for release APK builds
-keep class androidx.media3.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
