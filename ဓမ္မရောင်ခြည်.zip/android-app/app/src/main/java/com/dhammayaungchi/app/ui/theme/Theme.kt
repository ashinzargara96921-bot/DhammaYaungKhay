package com.dhammayaungchi.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val DhammaColorScheme = darkColorScheme(
    primary = AntiqueGold,
    onPrimary = DeepTeakBackground,
    primaryContainer = ElevatedBrownSurface,
    onPrimaryContainer = BurnishedGold,
    secondary = BurnishedGold,
    onSecondary = DeepTeakBackground,
    background = DeepTeakBackground,
    onBackground = IvoryText,
    surface = TempleBrownSurface,
    onSurface = IvoryText,
    surfaceVariant = ElevatedBrownSurface,
    onSurfaceVariant = WarmSandText,
    outline = HairlineBrownBorder,
    error = LotusCrimson,
    onError = IvoryText
)

private val DhammaTypography = Typography(
    headlineLarge = TextStyle(
        fontSize = 26.sp,
        lineHeight = 36.sp,
        fontWeight = FontWeight.Bold,
        color = IvoryText
    ),
    headlineMedium = TextStyle(
        fontSize = 20.sp,
        lineHeight = 28.sp,
        fontWeight = FontWeight.SemiBold,
        color = IvoryText
    ),
    titleLarge = TextStyle(
        fontSize = 18.sp,
        lineHeight = 26.sp,
        fontWeight = FontWeight.SemiBold,
        color = IvoryText
    ),
    titleMedium = TextStyle(
        fontSize = 16.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Medium,
        color = IvoryText
    ),
    bodyLarge = TextStyle(
        fontSize = 15.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Normal,
        color = IvoryText
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        lineHeight = 20.sp,
        fontWeight = FontWeight.Normal,
        color = WarmSandText
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        lineHeight = 16.sp,
        fontWeight = FontWeight.Medium,
        color = WarmSandText
    )
)

@Composable
fun DhammaYaungChiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DhammaColorScheme,
        typography = DhammaTypography,
        content = content
    )
}
