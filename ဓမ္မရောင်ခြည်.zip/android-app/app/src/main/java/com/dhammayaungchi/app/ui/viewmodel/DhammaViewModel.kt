package com.dhammayaungchi.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dhammayaungchi.app.BuildConfig
import com.dhammayaungchi.app.data.local.UserPreferencesManager
import com.dhammayaungchi.app.data.model.AdminSessionState
import com.dhammayaungchi.app.data.model.DhammaCategories
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.data.model.MediaType
import com.dhammayaungchi.app.data.model.UploadProgressState
import com.dhammayaungchi.app.data.repository.DhammaRepository
import com.dhammayaungchi.app.player.AudioPlayerUiState
import com.dhammayaungchi.app.player.DhammaPlayerManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class DhammaUiState(
    val isLoading: Boolean = true,
    val errorMessage: String? = null,
    val allContents: List<DhammaContent> = emptyList(),
    val filteredContents: List<DhammaContent> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: String = DhammaCategories.ALL,
    val selectedMediaFilter: MediaType? = null,
    val favoriteIds: Set<String> = emptySet(),
    val recentIds: List<String> = emptyList(),
    val activeVideoItem: DhammaContent? = null
)

class DhammaViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsManager = UserPreferencesManager(application)
    private val repository = DhammaRepository(application, prefsManager)
    val playerManager = DhammaPlayerManager(application)

    private val _searchQuery = MutableStateFlow("")
    private val _selectedCategory = MutableStateFlow(DhammaCategories.ALL)
    private val _selectedMediaFilter = MutableStateFlow<MediaType?>(null)
    private val _activeVideo = MutableStateFlow<DhammaContent?>(null)
    private val _rawContents = MutableStateFlow<List<DhammaContent>>(emptyList())
    private val _isLoading = MutableStateFlow(true)
    private val _feedError = MutableStateFlow<String?>(null)

    private val _adminSession = MutableStateFlow(AdminSessionState(isChecking = true))
    val adminSession: StateFlow<AdminSessionState> = _adminSession.asStateFlow()

    private val _uploadState = MutableStateFlow(UploadProgressState())
    val uploadState: StateFlow<UploadProgressState> = _uploadState.asStateFlow()

    val serverUrl: StateFlow<String> = prefsManager.serverUrlFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, BuildConfig.DEFAULT_SERVER_URL)

    val audioState: StateFlow<AudioPlayerUiState> = playerManager.state

    val uiState: StateFlow<DhammaUiState> = combine(
        _rawContents,
        _isLoading,
        _feedError,
        _searchQuery,
        _selectedCategory,
        _selectedMediaFilter,
        prefsManager.favoriteIdsFlow,
        prefsManager.recentIdsFlow,
        _activeVideo
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val items = values[0] as List<DhammaContent>
        val loading = values[1] as Boolean
        val error = values[2] as String?
        val query = values[3] as String
        val category = values[4] as String
        val mediaFilter = values[5] as MediaType?
        @Suppress("UNCHECKED_CAST")
        val favorites = values[6] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val recents = values[7] as List<String>
        val activeVideo = values[8] as DhammaContent?

        val filtered = items.filter { item ->
            val matchesCategory = category == DhammaCategories.ALL || item.category == category
            val matchesType = mediaFilter == null || item.mediaType == mediaFilter
            val matchesQuery = query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.preacher.contains(query, ignoreCase = true) ||
                item.category.contains(query, ignoreCase = true) ||
                item.description.contains(query, ignoreCase = true)
            matchesCategory && matchesType && matchesQuery
        }

        DhammaUiState(
            isLoading = loading,
            errorMessage = error,
            allContents = items,
            filteredContents = filtered,
            searchQuery = query,
            selectedCategory = category,
            selectedMediaFilter = mediaFilter,
            favoriteIds = favorites,
            recentIds = recents,
            activeVideoItem = activeVideo
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DhammaUiState())

    init {
        startPublicSyncLoop()
        restoreAdminSession()
    }

    private fun startPublicSyncLoop() {
        viewModelScope.launch {
            while (isActive) {
                refreshPublicFeed()
                delay(15_000L)
            }
        }
    }

    fun refreshPublicFeed() {
        viewModelScope.launch {
            val result = repository.fetchDhammaContents()
            _isLoading.value = false
            result.onSuccess { items ->
                _rawContents.value = items
                _feedError.value = null
            }.onFailure { err ->
                if (_rawContents.value.isEmpty()) {
                    _feedError.value = err.localizedMessage ?: "ဒေတာရယူရာတွင် အမှားဖြစ်ပွားပါသည်"
                }
            }
        }
    }

    fun restoreAdminSession() {
        viewModelScope.launch {
            _adminSession.value = _adminSession.value.copy(isChecking = true)
            _adminSession.value = repository.checkAdminStatus()
        }
    }

    fun updateServerUrl(newUrl: String) {
        viewModelScope.launch {
            prefsManager.setServerUrl(newUrl)
            _isLoading.value = true
            refreshPublicFeed()
            restoreAdminSession()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun selectMediaFilter(type: MediaType?) {
        _selectedMediaFilter.value = type
    }

    fun playDhammaItem(item: DhammaContent) {
        viewModelScope.launch {
            prefsManager.recordRecentlyPlayed(item.id)
        }
        if (item.mediaType == MediaType.MP3) {
            _activeVideo.value = null
            playerManager.playAudio(item)
        } else {
            playerManager.stopAndClear()
            _activeVideo.value = item
        }
    }

    fun closeVideoPlayer() {
        _activeVideo.value = null
    }

    fun toggleFavorite(id: String) {
        viewModelScope.launch {
            prefsManager.toggleFavorite(id)
        }
    }

    fun signInAdmin(email: String, password: String) {
        viewModelScope.launch {
            val isConfigured = _adminSession.value.isServerConfigured
            _adminSession.value = _adminSession.value.copy(isChecking = true, errorMessage = null)
            val res = repository.signInOrSetupAdmin(email, password, isConfigured)
            res.onSuccess { signedEmail ->
                _adminSession.value = AdminSessionState(
                    isChecking = false,
                    isServerConfigured = true,
                    isAdminAuthenticated = true,
                    email = signedEmail
                )
            }.onFailure { err ->
                _adminSession.value = _adminSession.value.copy(
                    isChecking = false,
                    isAdminAuthenticated = false,
                    errorMessage = err.localizedMessage ?: "အကောင့်ဝင်ရောက်မှု မအောင်မြင်ပါ"
                )
            }
        }
    }

    fun signOutAdmin() {
        viewModelScope.launch {
            repository.signOutAdmin()
            _adminSession.value = _adminSession.value.copy(
                isChecking = false,
                isAdminAuthenticated = false,
                email = null,
                errorMessage = null
            )
        }
    }

    fun uploadDhammaContent(
        fileUri: Uri?,
        externalMediaUrl: String?,
        title: String,
        preacher: String,
        category: String,
        description: String,
        mediaType: MediaType,
        durationText: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            _uploadState.value = UploadProgressState(
                isUploading = true,
                statusMessage = "တရားတော်ဖိုင် တင်သွင်းနေပါသည်..."
            )
            val res = repository.uploadDhammaContent(
                fileUri = fileUri,
                externalMediaUrl = externalMediaUrl,
                title = title,
                preacher = preacher,
                category = category,
                description = description,
                mediaType = mediaType,
                durationText = durationText
            )
            _uploadState.value = UploadProgressState()
            res.onSuccess {
                refreshPublicFeed()
                onComplete(true, "တရားတော် အသစ်တင်သွင်းခြင်း အောင်မြင်ပါသည်")
            }.onFailure { err ->
                onComplete(false, err.localizedMessage ?: "တင်သွင်းရာတွင် အမှားဖြစ်ပွားပါသည်")
            }
        }
    }

    fun updateDhammaMetadata(
        existing: DhammaContent,
        title: String,
        preacher: String,
        category: String,
        description: String,
        mediaType: MediaType,
        durationText: String,
        onComplete: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.updateDhammaMetadata(
                existing, title, preacher, category, description, mediaType, durationText
            )
            res.onSuccess {
                refreshPublicFeed()
                onComplete(true, "အချက်အလက် ပြင်ဆင်ပြီးပါပြီ")
            }.onFailure { err ->
                onComplete(false, err.localizedMessage ?: "ပြင်ဆင်မှု မအောင်မြင်ပါ")
            }
        }
    }

    fun deleteDhammaContent(content: DhammaContent, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.deleteDhammaContent(content)
            res.onSuccess {
                refreshPublicFeed()
                onComplete(true, "ဖျက်သိမ်းပြီးပါပြီ")
            }.onFailure { err ->
                onComplete(false, err.localizedMessage ?: "ဖျက်သိမ်းမှု မအောင်မြင်ပါ")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
