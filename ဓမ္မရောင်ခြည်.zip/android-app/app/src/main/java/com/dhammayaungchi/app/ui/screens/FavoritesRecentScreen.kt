package com.dhammayaungchi.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.ui.components.DhammaTalkCard
import com.dhammayaungchi.app.ui.theme.*
import com.dhammayaungchi.app.ui.viewmodel.DhammaUiState

@Composable
fun FavoritesRecentScreen(
    uiState: DhammaUiState,
    activeAudioId: String?,
    onPlayItem: (DhammaContent) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    val favoriteItems = remember(uiState.allContents, uiState.favoriteIds) {
        uiState.allContents.filter { uiState.favoriteIds.contains(it.id) }
    }

    val recentItems = remember(uiState.allContents, uiState.recentIds) {
        val byId = uiState.allContents.associateBy { it.id }
        uiState.recentIds.mapNotNull { byId[it] }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "နှစ်သက်ရာနှင့် မကြာသေးမီက",
            style = MaterialTheme.typography.headlineMedium,
            color = BurnishedGold
        )
        Spacer(modifier = Modifier.height(12.dp))

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = TempleBrownSurface,
            contentColor = BurnishedGold
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("နှစ်သက်ရာ (${favoriteItems.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("မကြာသေးမီ (${recentItems.size})") }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        val displayList = if (selectedTab == 0) favoriteItems else recentItems
        val emptyText = if (selectedTab == 0) {
            "နှစ်သက်ရာ တရားတော်များ မရှိသေးပါ။ နှလုံးသားပုံကို နှိပ်၍ သိမ်းဆည်းနိုင်ပါသည်။"
        } else {
            "မကြာသေးမီက နားထောင်ခဲ့သော တရားတော်များ မရှိသေးပါ။"
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (displayList.isEmpty()) {
                item {
                    Text(
                        text = emptyText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmSandText,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            } else {
                items(displayList, key = { it.id }) { item ->
                    DhammaTalkCard(
                        item = item,
                        isFavorite = uiState.favoriteIds.contains(item.id),
                        isCurrentlyPlaying = activeAudioId == item.id,
                        onPlayClick = { onPlayItem(item) },
                        onToggleFavorite = { onToggleFavorite(item.id) }
                    )
                }
            }
        }
    }
}
