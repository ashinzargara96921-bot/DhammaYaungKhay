package com.dhammayaungchi.app

import android.app.Application

class DhammaApplication : Application()
