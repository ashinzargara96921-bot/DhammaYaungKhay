package com.dhammayaungchi.app.player

import android.content.ComponentName
import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.dhammayaungchi.app.data.model.DhammaContent
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class AudioPlayerUiState(
    val activeTrack: DhammaContent? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

class DhammaPlayerManager(context: Context) {

    private val scope = CoroutineScope(Dispatchers.Main)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var progressJob: Job? = null

    private val _state = MutableStateFlow(AudioPlayerUiState())
    val state: StateFlow<AudioPlayerUiState> = _state.asStateFlow()

    init {
        val sessionToken = SessionToken(
            context,
            ComponentName(context, DhammaPlaybackService::class.java)
        )
        val future = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener({
            val controller = future.get()
            mediaController = controller
            attachListener(controller)
        }, MoreExecutors.directExecutor())
    }

    private fun attachListener(controller: MediaController) {
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _state.value = _state.value.copy(isPlaying = isPlaying)
                if (isPlaying) startProgressPolling() else stopProgressPolling()
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _state.value = _state.value.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = controller.duration.coerceAtLeast(0L)
                )
            }
        })
    }

    fun playAudio(item: DhammaContent) {
        val controller = mediaController ?: return
        val metadata = MediaMetadata.Builder()
            .setTitle(item.title)
            .setArtist(item.preacher)
            .build()
        val mediaItem = MediaItem.Builder()
            .setMediaId(item.id)
            .setUri(item.mediaUrl)
            .setMediaMetadata(metadata)
            .build()

        _state.value = _state.value.copy(
            activeTrack = item,
            currentPositionMs = 0L,
            durationMs = 0L,
            isBuffering = true
        )
        controller.setMediaItem(mediaItem)
        controller.prepare()
        controller.play()
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) controller.pause() else controller.play()
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs.coerceAtLeast(0L))
        _state.value = _state.value.copy(currentPositionMs = positionMs.coerceAtLeast(0L))
    }

    fun skipBy(deltaMs: Long) {
        val controller = mediaController ?: return
        val target = (controller.currentPosition + deltaMs).coerceIn(
            0L,
            controller.duration.coerceAtLeast(0L)
        )
        controller.seekTo(target)
        _state.value = _state.value.copy(currentPositionMs = target)
    }

    fun setPlaybackSpeed(speed: Float) {
        mediaController?.setPlaybackSpeed(speed)
        _state.value = _state.value.copy(playbackSpeed = speed)
    }

    fun stopAndClear() {
        mediaController?.stop()
        stopProgressPolling()
        _state.value = AudioPlayerUiState()
    }

    private fun startProgressPolling() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val controller = mediaController
                if (controller != null) {
                    _state.value = _state.value.copy(
                        currentPositionMs = controller.currentPosition.coerceAtLeast(0L),
                        durationMs = controller.duration.coerceAtLeast(0L)
                    )
                }
                delay(400L)
            }
        }
    }

    private fun stopProgressPolling() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stopProgressPolling()
        controllerFuture?.let { MediaController.releaseFuture(it) }
    }
}
