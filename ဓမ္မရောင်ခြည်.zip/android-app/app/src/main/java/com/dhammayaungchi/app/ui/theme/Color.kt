package com.dhammayaungchi.app.ui.theme

import androidx.compose.ui.graphics.Color

// Buddhist Dark Brown & Antique Gold Palette
val DeepTeakBackground = Color(0xFF160F0A)
val TempleBrownSurface = Color(0xFF221811)
val ElevatedBrownSurface = Color(0xFF2E2117)
val HairlineBrownBorder = Color(0xFF422E1E)

val AntiqueGold = Color(0xFFD4AF37)
val BurnishedGold = Color(0xFFE8C668)
val MutedAmberGold = Color(0xFFB38B2D)
val SoftGoldGlow = Color(0x33D4AF37)

val IvoryText = Color(0xFFF6EFE4)
val WarmSandText = Color(0xFFCBBBA3)
val MutedBronzeText = Color(0xFF8F7B64)

val LotusCrimson = Color(0xFFC94A4A)
val SaffronSuccess = Color(0xFF4D9B6A)
