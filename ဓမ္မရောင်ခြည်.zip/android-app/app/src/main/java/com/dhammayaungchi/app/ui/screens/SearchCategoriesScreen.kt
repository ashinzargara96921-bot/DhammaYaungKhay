package com.dhammayaungchi.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.dhammayaungchi.app.data.model.DhammaCategories
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.ui.components.DhammaTalkCard
import com.dhammayaungchi.app.ui.theme.*
import com.dhammayaungchi.app.ui.viewmodel.DhammaUiState

@Composable
fun SearchCategoriesScreen(
    uiState: DhammaUiState,
    activeAudioId: String?,
    onSearchChange: (String) -> Unit,
    onSelectCategory: (String) -> Unit,
    onPlayItem: (DhammaContent) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "တရားတော် ရှာဖွေရန်",
            style = MaterialTheme.typography.headlineMedium,
            color = BurnishedGold
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = onSearchChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("တရားခေါင်းစဉ်၊ ဆရာတော်အမည် ရှာဖွေပါ...", color = MutedBronzeText) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AntiqueGold) },
            trailingIcon = {
                if (uiState.searchQuery.isNotBlank()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "ရှင်းလင်းရန်", tint = WarmSandText)
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AntiqueGold,
                unfocusedBorderColor = HairlineBrownBorder,
                focusedContainerColor = TempleBrownSurface,
                unfocusedContainerColor = TempleBrownSurface,
                focusedTextColor = IvoryText,
                unfocusedTextColor = IvoryText
            )
        )

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "ကဏ္ဍအလိုက် ရွေးချယ်ရန်",
            style = MaterialTheme.typography.titleMedium,
            color = IvoryText
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Category Grid (2 columns)
        val categories = listOf(DhammaCategories.ALL) + DhammaCategories.LIST
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            categories.chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowItems.forEach { cat ->
                        val isSelected = uiState.selectedCategory == cat
                        val count = if (cat == DhammaCategories.ALL) {
                            uiState.allContents.size
                        } else {
                            uiState.allContents.count { it.category == cat }
                        }
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSelectCategory(cat) },
                            color = if (isSelected) ElevatedBrownSurface else TempleBrownSurface,
                            border = BorderStroke(1.dp, if (isSelected) AntiqueGold else HairlineBrownBorder),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = cat,
                                    color = if (isSelected) BurnishedGold else IvoryText,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "$count",
                                    color = if (isSelected) AntiqueGold else MutedBronzeText,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uiState.filteredContents.isEmpty()) {
                item {
                    Text(
                        text = "ရှာဖွေမှုနှင့် ကိုက်ညီသော တရားတော် မတွေ့ရှိပါ။",
                        color = WarmSandText,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }
            } else {
                items(uiState.filteredContents, key = { it.id }) { item ->
                    DhammaTalkCard(
                        item = item,
                        isFavorite = uiState.favoriteIds.contains(item.id),
                        isCurrentlyPlaying = activeAudioId == item.id,
                        onPlayClick = { onPlayItem(item) },
                        onToggleFavorite = { onToggleFavorite(item.id) }
                    )
                }
            }
        }
    }
}
