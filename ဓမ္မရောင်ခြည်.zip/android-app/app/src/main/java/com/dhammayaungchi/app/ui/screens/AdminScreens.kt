package com.dhammayaungchi.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.dhammayaungchi.app.data.model.AdminSessionState
import com.dhammayaungchi.app.data.model.DhammaCategories
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.data.model.MediaType
import com.dhammayaungchi.app.data.model.UploadProgressState
import com.dhammayaungchi.app.ui.theme.*

@Composable
fun AdminPortalScreen(
    adminSession: AdminSessionState,
    serverUrl: String,
    uploadState: UploadProgressState,
    contents: List<DhammaContent>,
    onUpdateServerUrl: (String) -> Unit,
    onSignIn: (String, String) -> Unit,
    onSignOut: () -> Unit,
    onUpload: (Uri?, String?, String, String, String, String, MediaType, String, (Boolean, String) -> Unit) -> Unit,
    onUpdate: (DhammaContent, String, String, String, String, MediaType, String, (Boolean, String) -> Unit) -> Unit,
    onDelete: (DhammaContent, (Boolean, String) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    if (!adminSession.isAdminAuthenticated) {
        AdminLoginView(
            isChecking = adminSession.isChecking,
            isServerConfigured = adminSession.isServerConfigured,
            serverUrl = serverUrl,
            errorMessage = adminSession.errorMessage,
            onUpdateServerUrl = onUpdateServerUrl,
            onSignIn = onSignIn,
            modifier = modifier
        )
    } else {
        AdminDashboardView(
            adminEmail = adminSession.email.orEmpty(),
            serverUrl = serverUrl,
            uploadState = uploadState,
            contents = contents,
            onUpdateServerUrl = onUpdateServerUrl,
            onSignOut = onSignOut,
            onUpload = onUpload,
            onUpdate = onUpdate,
            onDelete = onDelete,
            modifier = modifier
        )
    }
}

@Composable
private fun ServerUrlCard(
    currentUrl: String,
    onSaveUrl: (String) -> Unit
) {
    var draftUrl by remember(currentUrl) { mutableStateOf(currentUrl) }
    Surface(
        color = TempleBrownSurface,
        border = BorderStroke(1.dp, HairlineBrownBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ဆာဗာလိပ်စာ (Server URL)", style = MaterialTheme.typography.titleMedium, color = BurnishedGold)
            OutlinedTextField(
                value = draftUrl,
                onValueChange = { draftUrl = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("http://10.0.2.2:3000") }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { draftUrl = "http://10.0.2.2:3000" }) {
                    Text("Emulator")
                }
                Button(
                    onClick = { onSaveUrl(draftUrl) },
                    colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold, contentColor = DeepTeakBackground)
                ) {
                    Text("ချိတ်ဆက်မည်")
                }
            }
        }
    }
}

@Composable
private fun AdminLoginView(
    isChecking: Boolean,
    isServerConfigured: Boolean,
    serverUrl: String,
    errorMessage: String?,
    onUpdateServerUrl: (String) -> Unit,
    onSignIn: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
            .padding(horizontal = 20.dp),
        contentPadding = PaddingValues(vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = if (isServerConfigured) "စီမံခန့်ခွဲသူ (Admin) ဝင်ရောက်ရန်" else "စီမံခန့်ခွဲသူ အကောင့် သတ်မှတ်ရန်",
                style = MaterialTheme.typography.headlineMedium,
                color = BurnishedGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "သာမန်အသုံးပြုသူများ အကောင့်ဝင်ရန် မလိုအပ်ပါ။ တရားတော်များ တင်သွင်း၊ ပြင်ဆင်၊ ဖျက်သိမ်းရန်အတွက်သာ စီမံသူ ဝင်ရောက်ရပါမည်။",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmSandText
            )
        }

        item {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("အီးမေးလ် (Email)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("စကားဝှက် (Password)") },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            if (!errorMessage.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(text = errorMessage, color = LotusCrimson, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = { onSignIn(email, password) },
                enabled = !isChecking && email.isNotBlank() && password.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold, contentColor = DeepTeakBackground)
            ) {
                if (isChecking) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), color = DeepTeakBackground)
                } else {
                    Text(if (isServerConfigured) "အကောင့်ဝင်ရန်" else "စီမံသူအကောင့် ဖန်တီးရန်")
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            ServerUrlCard(currentUrl = serverUrl, onSaveUrl = onUpdateServerUrl)
        }
    }
}

@Composable
private fun AdminDashboardView(
    adminEmail: String,
    serverUrl: String,
    uploadState: UploadProgressState,
    contents: List<DhammaContent>,
    onUpdateServerUrl: (String) -> Unit,
    onSignOut: () -> Unit,
    onUpload: (Uri?, String?, String, String, String, String, MediaType, String, (Boolean, String) -> Unit) -> Unit,
    onUpdate: (DhammaContent, String, String, String, String, MediaType, String, (Boolean, String) -> Unit) -> Unit,
    onDelete: (DhammaContent, (Boolean, String) -> Unit) -> Unit,
    modifier: Modifier = Modifier
) {
    var editingItem by remember { mutableStateOf<DhammaContent?>(null) }
    var title by remember { mutableStateOf("") }
    var preacher by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(DhammaCategories.LIST.first()) }
    var description by remember { mutableStateOf("") }
    var mediaType by remember { mutableStateOf(MediaType.MP3) }
    var durationText by remember { mutableStateOf("") }
    var externalUrl by remember { mutableStateOf("") }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        selectedFileUri = uri
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("စီမံခန့်ခွဲမှု စင်တာ", style = MaterialTheme.typography.headlineMedium, color = BurnishedGold)
                    Text(adminEmail, style = MaterialTheme.typography.labelMedium, color = WarmSandText)
                }
                IconButton(onClick = onSignOut) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = "ထွက်ရန်", tint = AntiqueGold)
                }
            }
        }

        item {
            ServerUrlCard(currentUrl = serverUrl, onSaveUrl = onUpdateServerUrl)
        }

        item {
            Surface(
                color = TempleBrownSurface,
                border = BorderStroke(1.dp, HairlineBrownBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (editingItem == null) "တရားတော်အသစ် တင်သွင်းရန်" else "တရားတော် ပြင်ဆင်ရန်",
                        style = MaterialTheme.typography.titleLarge,
                        color = IvoryText
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MediaType.entries.forEach { type ->
                            val selected = mediaType == type
                            FilterChip(
                                selected = selected,
                                onClick = { mediaType = type },
                                label = { Text(type.labelBurmese) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("တရားခေါင်းစဉ်") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = preacher,
                        onValueChange = { preacher = it },
                        label = { Text("ဟောကြားသူ ဆရာတော် / ရွတ်ဖတ်သူ") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("ကဏ္ဍ - $category")
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            DhammaCategories.LIST.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        category = cat
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = durationText,
                        onValueChange = { durationText = it },
                        label = { Text("ကြာချိန် (ဥပမာ 45:20)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("အကြောင်းအရာ အကျဉ်း") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (editingItem == null) {
                        OutlinedButton(
                            onClick = {
                                val mime = if (mediaType == MediaType.MP3) "audio/*" else "video/*"
                                filePicker.launch(mime)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (selectedFileUri == null) "MP3 / MP4 ဖိုင် ရွေးချယ်ရန်"
                                else "ဖိုင် ရွေးချယ်ပြီးပါပြီ"
                            )
                        }

                        OutlinedTextField(
                            value = externalUrl,
                            onValueChange = { externalUrl = it },
                            label = { Text("သို့မဟုတ် တိုက်ရိုက် Media URL (Optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (uploadState.isUploading) {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth(),
                            color = AntiqueGold
                        )
                        Text(uploadState.statusMessage, color = BurnishedGold)
                    }

                    if (!feedbackMessage.isNullOrBlank()) {
                        Text(feedbackMessage!!, color = BurnishedGold, style = MaterialTheme.typography.bodyMedium)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                val currentEdit = editingItem
                                if (currentEdit != null) {
                                    onUpdate(currentEdit, title, preacher, category, description, mediaType, durationText) { ok, msg ->
                                        feedbackMessage = msg
                                        if (ok) {
                                            editingItem = null
                                            title = ""; preacher = ""; description = ""; durationText = ""
                                        }
                                    }
                                } else {
                                    onUpload(selectedFileUri, externalUrl, title, preacher, category, description, mediaType, durationText) { ok, msg ->
                                        feedbackMessage = msg
                                        if (ok) {
                                            title = ""; preacher = ""; description = ""; durationText = ""; externalUrl = ""; selectedFileUri = null
                                        }
                                    }
                                }
                            },
                            enabled = !uploadState.isUploading && title.isNotBlank() && preacher.isNotBlank(),
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = AntiqueGold, contentColor = DeepTeakBackground)
                        ) {
                            Text(if (editingItem == null) "တင်သွင်းရန်" else "သိမ်းဆည်းရန်")
                        }

                        if (editingItem != null) {
                            OutlinedButton(onClick = {
                                editingItem = null
                                title = ""; preacher = ""; description = ""; durationText = ""
                            }) {
                                Text("မလုပ်တော့ပါ")
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "တင်သွင်းပြီးသော တရားတော်များ (${contents.size})",
                style = MaterialTheme.typography.titleMedium,
                color = IvoryText
            )
        }

        items(contents, key = { it.id }) { item ->
            Surface(
                color = TempleBrownSurface,
                border = BorderStroke(1.dp, HairlineBrownBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.title, color = IvoryText, style = MaterialTheme.typography.titleMedium)
                        Text("${item.preacher} · ${item.category} · ${item.mediaType.name}", color = WarmSandText, style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = {
                        editingItem = item
                        title = item.title
                        preacher = item.preacher
                        category = item.category
                        description = item.description
                        mediaType = item.mediaType
                        durationText = item.durationText
                    }) {
                        Icon(Icons.Default.Edit, contentDescription = "ပြင်ဆင်ရန်", tint = AntiqueGold)
                    }
                    IconButton(onClick = {
                        onDelete(item) { _, msg -> feedbackMessage = msg }
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "ဖျက်သိမ်းရန်", tint = LotusCrimson)
                    }
                }
            }
        }
    }
}
