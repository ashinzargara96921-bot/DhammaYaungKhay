package com.dhammayaungchi.app.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.dhammayaungchi.app.data.local.UserPreferencesManager
import com.dhammayaungchi.app.data.model.AdminSessionState
import com.dhammayaungchi.app.data.model.DhammaCategories
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class DhammaRepository(
    private val context: Context,
    private val prefsManager: UserPreferencesManager
) {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun resolveMediaUrl(baseUrl: String, rawUrl: String): String {
        val trimmed = rawUrl.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
            trimmed
        } else if (trimmed.startsWith("/")) {
            "$baseUrl$trimmed"
        } else {
            "$baseUrl/$trimmed"
        }
    }

    private fun parseDhammaItem(baseUrl: String, obj: JSONObject): DhammaContent {
        val mediaTypeStr = obj.optString("mediaType", "MP3")
        val parsedType = runCatching { MediaType.valueOf(mediaTypeStr) }.getOrDefault(MediaType.MP3)
        return DhammaContent(
            id = obj.optString("id"),
            title = obj.optString("title"),
            preacher = obj.optString("preacher"),
            category = obj.optString("category", DhammaCategories.LIST.first()),
            description = obj.optString("description"),
            mediaType = parsedType,
            mediaUrl = resolveMediaUrl(baseUrl, obj.optString("mediaUrl")),
            durationText = obj.optString("durationText", "00:00"),
            createdAt = obj.optString("createdAt"),
            updatedAt = obj.optString("updatedAt")
        )
    }

    private fun extractErrorMessage(body: String?, fallback: String): String {
        if (body.isNullOrBlank()) return fallback
        return runCatching {
            val json = JSONObject(body)
            json.optString("error").ifBlank { fallback }
        }.getOrDefault(fallback)
    }

    suspend fun fetchDhammaContents(): Result<List<DhammaContent>> = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        return@withContext try {
            val req = Request.Builder()
                .url("$baseUrl/api/dhamma")
                .get()
                .build()
            httpClient.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException(extractErrorMessage(body, "တရားတော်များ ရယူ၍မရပါ (HTTP ${res.code})"))
                    )
                }
                val root = JSONObject(body)
                val arr: JSONArray = root.optJSONArray("items") ?: JSONArray()
                val items = buildList {
                    for (i in 0 until arr.length()) {
                        add(parseDhammaItem(baseUrl, arr.getJSONObject(i)))
                    }
                }
                Result.success(items)
            }
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("ဆာဗာ ($baseUrl) နှင့် ချိတ်ဆက်၍ မရပါ: ${e.localizedMessage ?: ""}")
            )
        }
    }

    suspend fun checkAdminStatus(): AdminSessionState = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        val token = prefsManager.getAdminToken()
        return@withContext try {
            val builder = Request.Builder()
                .url("$baseUrl/api/admin/status")
                .get()
            if (!token.isNullOrBlank()) {
                builder.addHeader("Authorization", "Bearer $token")
            }
            httpClient.newCall(builder.build()).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext AdminSessionState(isChecking = false, isAdminAuthenticated = false)
                }
                val json = JSONObject(body)
                val configured = json.optBoolean("isConfigured", true)
                val authenticated = json.optBoolean("isAuthenticated", false)
                val email = json.optString("email").takeIf { it.isNotBlank() && it != "null" }
                if (!authenticated && !token.isNullOrBlank()) {
                    prefsManager.clearAdminSession()
                }
                AdminSessionState(
                    isChecking = false,
                    isServerConfigured = configured,
                    isAdminAuthenticated = authenticated,
                    email = email
                )
            }
        } catch (_: Exception) {
            AdminSessionState(isChecking = false, isAdminAuthenticated = false)
        }
    }

    suspend fun signInOrSetupAdmin(
        email: String,
        password: String,
        isConfigured: Boolean
    ): Result<String> = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        val endpoint = if (isConfigured) "/api/admin/login" else "/api/admin/setup"
        return@withContext try {
            val payload = JSONObject()
                .put("email", email.trim())
                .put("password", password)
                .toString()
                .toRequestBody(jsonMediaType)

            val req = Request.Builder()
                .url("$baseUrl$endpoint")
                .post(payload)
                .build()

            httpClient.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException(extractErrorMessage(body, "အကောင့်ဝင်ရောက်မှု မအောင်မြင်ပါ"))
                    )
                }
                val json = JSONObject(body)
                val token = json.optString("token")
                val resolvedEmail = json.optString("email", email.trim())
                if (token.isBlank()) {
                    return@withContext Result.failure(
                        IllegalStateException("Session token မရရှိပါ")
                    )
                }
                prefsManager.saveAdminSession(token, resolvedEmail)
                Result.success(resolvedEmail)
            }
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("ဆာဗာနှင့် ချိတ်ဆက်၍ မရပါ: ${e.localizedMessage ?: ""}")
            )
        }
    }

    suspend fun signOutAdmin() = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        prefsManager.clearAdminSession()
        runCatching {
            val req = Request.Builder()
                .url("$baseUrl/api/admin/logout")
                .post(ByteArray(0).toRequestBody(null))
                .build()
            httpClient.newCall(req).execute().close()
        }
    }

    private fun resolveDisplayName(uri: Uri, fallbackExt: String): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) {
                        val name = cursor.getString(idx)
                        if (!name.isNullOrBlank()) return name
                    }
                }
            }
        return "dhamma_${System.currentTimeMillis()}.$fallbackExt"
    }

    suspend fun uploadDhammaContent(
        fileUri: Uri?,
        externalMediaUrl: String?,
        title: String,
        preacher: String,
        category: String,
        description: String,
        mediaType: MediaType,
        durationText: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        val token = prefsManager.getAdminToken()
            ?: return@withContext Result.failure(IllegalStateException("စီမံခန့်ခွဲသူအဖြစ် ဝင်ရောက်ထားရန် လိုအပ်ပါသည်"))

        return@withContext try {
            val multipart = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("title", title.trim())
                .addFormDataPart("preacher", preacher.trim())
                .addFormDataPart("category", category)
                .addFormDataPart("description", description.trim())
                .addFormDataPart("mediaType", mediaType.name)
                .addFormDataPart("durationText", durationText.ifBlank { "00:00" })

            if (!externalMediaUrl.isNullOrBlank()) {
                multipart.addFormDataPart("externalUrl", externalMediaUrl.trim())
            }

            if (fileUri != null) {
                val fallbackExt = if (mediaType == MediaType.MP3) "mp3" else "mp4"
                val fileName = resolveDisplayName(fileUri, fallbackExt)
                val mime = context.contentResolver.getType(fileUri)
                    ?: if (mediaType == MediaType.MP3) "audio/mpeg" else "video/mp4"
                val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
                    ?: return@withContext Result.failure(IllegalStateException("ရွေးချယ်ထားသော ဖိုင်ကို ဖတ်ရှု၍မရပါ"))

                multipart.addFormDataPart(
                    "mediaFile",
                    fileName,
                    bytes.toRequestBody(mime.toMediaTypeOrNull())
                )
            }

            val req = Request.Builder()
                .url("$baseUrl/api/admin/dhamma")
                .addHeader("Authorization", "Bearer $token")
                .post(multipart.build())
                .build()

            httpClient.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException(extractErrorMessage(body, "တင်သွင်းမှု မအောင်မြင်ပါ"))
                    )
                }
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("တင်သွင်းရာတွင် အမှားဖြစ်ပွားပါသည်: ${e.localizedMessage ?: ""}"))
        }
    }

    suspend fun updateDhammaMetadata(
        existing: DhammaContent,
        title: String,
        preacher: String,
        category: String,
        description: String,
        mediaType: MediaType,
        durationText: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        val token = prefsManager.getAdminToken()
            ?: return@withContext Result.failure(IllegalStateException("စီမံခန့်ခွဲသူအဖြစ် ဝင်ရောက်ထားရန် လိုအပ်ပါသည်"))

        return@withContext try {
            val payload = JSONObject()
                .put("title", title.trim())
                .put("preacher", preacher.trim())
                .put("category", category)
                .put("description", description.trim())
                .put("mediaType", mediaType.name)
                .put("durationText", durationText.ifBlank { existing.durationText })
                .toString()
                .toRequestBody(jsonMediaType)

            val req = Request.Builder()
                .url("$baseUrl/api/admin/dhamma/${existing.id}")
                .addHeader("Authorization", "Bearer $token")
                .put(payload)
                .build()

            httpClient.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException(extractErrorMessage(body, "ပြင်ဆင်မှု မအောင်မြင်ပါ"))
                    )
                }
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("ပြင်ဆင်ရာတွင် အမှားဖြစ်ပွားပါသည်: ${e.localizedMessage ?: ""}"))
        }
    }

    suspend fun deleteDhammaContent(content: DhammaContent): Result<Unit> = withContext(Dispatchers.IO) {
        val baseUrl = prefsManager.getServerUrl()
        val token = prefsManager.getAdminToken()
            ?: return@withContext Result.failure(IllegalStateException("စီမံခန့်ခွဲသူအဖြစ် ဝင်ရောက်ထားရန် လိုအပ်ပါသည်"))

        return@withContext try {
            val req = Request.Builder()
                .url("$baseUrl/api/admin/dhamma/${content.id}")
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            httpClient.newCall(req).execute().use { res ->
                val body = res.body?.string().orEmpty()
                if (!res.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException(extractErrorMessage(body, "ဖျက်သိမ်းမှု မအောင်မြင်ပါ"))
                    )
                }
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(IllegalStateException("ဖျက်သိမ်းရာတွင် အမှားဖြစ်ပွားပါသည်: ${e.localizedMessage ?: ""}"))
        }
    }
}
