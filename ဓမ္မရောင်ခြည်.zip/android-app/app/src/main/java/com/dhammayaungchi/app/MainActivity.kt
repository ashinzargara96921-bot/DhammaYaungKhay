package com.dhammayaungchi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dhammayaungchi.app.ui.components.MiniAudioPlayerBar
import com.dhammayaungchi.app.ui.screens.*
import com.dhammayaungchi.app.ui.theme.*
import com.dhammayaungchi.app.ui.viewmodel.DhammaViewModel

enum class DhammaTab(val label: String) {
    HOME("ပင်မ"),
    SEARCH("ရှာဖွေရန်"),
    FAVORITES("နှစ်သက်ရာ"),
    ADMIN("စီမံသူ")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DhammaYaungChiTheme {
                DhammaAppRoot()
            }
        }
    }
}

@Composable
fun DhammaAppRoot(viewModel: DhammaViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val adminSession by viewModel.adminSession.collectAsStateWithLifecycle()
    val serverUrl by viewModel.serverUrl.collectAsStateWithLifecycle()
    val uploadState by viewModel.uploadState.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(DhammaTab.HOME) }
    var showFullAudioPlayer by remember { mutableStateOf(false) }

    val activeVideo = uiState.activeVideoItem
    if (activeVideo != null) {
        VideoPlayerScreen(
            item = activeVideo,
            isFavorite = uiState.favoriteIds.contains(activeVideo.id),
            onToggleFavorite = { viewModel.toggleFavorite(activeVideo.id) },
            onClose = { viewModel.closeVideoPlayer() }
        )
        return
    }

    if (showFullAudioPlayer && audioState.activeTrack != null) {
        val track = audioState.activeTrack!!
        FullAudioPlayerScreen(
            audioState = audioState,
            isFavorite = uiState.favoriteIds.contains(track.id),
            onToggleFavorite = { viewModel.toggleFavorite(track.id) },
            onTogglePlayPause = { viewModel.playerManager.togglePlayPause() },
            onSeekTo = { viewModel.playerManager.seekTo(it) },
            onSkipBy = { viewModel.playerManager.skipBy(it) },
            onSpeedChange = { viewModel.playerManager.setPlaybackSpeed(it) },
            onClose = { showFullAudioPlayer = false }
        )
        return
    }

    Scaffold(
        containerColor = DeepTeakBackground,
        bottomBar = {
            NavigationBar(containerColor = TempleBrownSurface, contentColor = BurnishedGold) {
                DhammaTab.entries.forEach { tab ->
                    val icon = when (tab) {
                        DhammaTab.HOME -> Icons.Default.Home
                        DhammaTab.SEARCH -> Icons.Default.Search
                        DhammaTab.FAVORITES -> Icons.Default.Favorite
                        DhammaTab.ADMIN -> Icons.Default.AdminPanelSettings
                    }
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = { currentTab = tab },
                        icon = { Icon(icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepTeakBackground,
                            selectedTextColor = BurnishedGold,
                            indicatorColor = AntiqueGold,
                            unselectedIconColor = WarmSandText,
                            unselectedTextColor = WarmSandText
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                DhammaTab.HOME -> HomeScreen(
                    uiState = uiState,
                    activeAudioId = audioState.activeTrack?.id,
                    onSelectCategory = viewModel::selectCategory,
                    onSelectMediaType = viewModel::selectMediaFilter,
                    onPlayItem = viewModel::playDhammaItem,
                    onToggleFavorite = viewModel::toggleFavorite
                )

                DhammaTab.SEARCH -> SearchCategoriesScreen(
                    uiState = uiState,
                    activeAudioId = audioState.activeTrack?.id,
                    onSearchChange = viewModel::updateSearchQuery,
                    onSelectCategory = viewModel::selectCategory,
                    onPlayItem = viewModel::playDhammaItem,
                    onToggleFavorite = viewModel::toggleFavorite
                )

                DhammaTab.FAVORITES -> FavoritesRecentScreen(
                    uiState = uiState,
                    activeAudioId = audioState.activeTrack?.id,
                    onPlayItem = viewModel::playDhammaItem,
                    onToggleFavorite = viewModel::toggleFavorite
                )

                DhammaTab.ADMIN -> AdminPortalScreen(
                    adminSession = adminSession,
                    serverUrl = serverUrl,
                    uploadState = uploadState,
                    contents = uiState.allContents,
                    onUpdateServerUrl = viewModel::updateServerUrl,
                    onSignIn = viewModel::signInAdmin,
                    onSignOut = viewModel::signOutAdmin,
                    onUpload = viewModel::uploadDhammaContent,
                    onUpdate = viewModel::updateDhammaMetadata,
                    onDelete = viewModel::deleteDhammaContent
                )
            }

            if (audioState.activeTrack != null) {
                MiniAudioPlayerBar(
                    audioState = audioState,
                    onTogglePlayPause = { viewModel.playerManager.togglePlayPause() },
                    onExpandClick = { showFullAudioPlayer = true },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                )
            }
        }
    }
}
