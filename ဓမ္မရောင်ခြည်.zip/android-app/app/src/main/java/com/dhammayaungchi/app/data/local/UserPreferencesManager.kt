package com.dhammayaungchi.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.dhammayaungchi.app.BuildConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dhammaPrefs: DataStore<Preferences> by preferencesDataStore(name = "dhamma_public_prefs")

class UserPreferencesManager(private val context: Context) {

    private val favoritesKey = stringSetPreferencesKey("favorite_dhamma_ids")
    private val recentIdsKey = stringPreferencesKey("recent_dhamma_ids_ordered")
    private val adminTokenKey = stringPreferencesKey("admin_bearer_token")
    private val adminEmailKey = stringPreferencesKey("admin_email")
    private val serverUrlKey = stringPreferencesKey("server_base_url")

    val favoriteIdsFlow: Flow<Set<String>> = context.dhammaPrefs.data.map { prefs ->
        prefs[favoritesKey] ?: emptySet()
    }

    val recentIdsFlow: Flow<List<String>> = context.dhammaPrefs.data.map { prefs ->
        val raw = prefs[recentIdsKey] ?: ""
        if (raw.isBlank()) emptyList() else raw.split(",").filter { it.isNotBlank() }
    }

    val serverUrlFlow: Flow<String> = context.dhammaPrefs.data.map { prefs ->
        val stored = prefs[serverUrlKey]?.trim()?.trimEnd('/')
        if (stored.isNullOrBlank()) BuildConfig.DEFAULT_SERVER_URL.trimEnd('/') else stored
    }

    suspend fun getServerUrl(): String = serverUrlFlow.first()

    suspend fun setServerUrl(url: String) {
        val cleaned = url.trim().trimEnd('/')
        context.dhammaPrefs.edit { prefs ->
            if (cleaned.isBlank()) {
                prefs.remove(serverUrlKey)
            } else {
                prefs[serverUrlKey] = cleaned
            }
        }
    }

    suspend fun getAdminToken(): String? = context.dhammaPrefs.data.first()[adminTokenKey]

    suspend fun getAdminEmail(): String? = context.dhammaPrefs.data.first()[adminEmailKey]

    suspend fun saveAdminSession(token: String, email: String) {
        context.dhammaPrefs.edit { prefs ->
            prefs[adminTokenKey] = token
            prefs[adminEmailKey] = email
        }
    }

    suspend fun clearAdminSession() {
        context.dhammaPrefs.edit { prefs ->
            prefs.remove(adminTokenKey)
            prefs.remove(adminEmailKey)
        }
    }

    suspend fun toggleFavorite(id: String) {
        context.dhammaPrefs.edit { prefs ->
            val current = prefs[favoritesKey]?.toMutableSet() ?: mutableSetOf()
            if (current.contains(id)) {
                current.remove(id)
            } else {
                current.add(id)
            }
            prefs[favoritesKey] = current
        }
    }

    suspend fun recordRecentlyPlayed(id: String) {
        context.dhammaPrefs.edit { prefs ->
            val current = (prefs[recentIdsKey] ?: "")
                .split(",")
                .filter { it.isNotBlank() && it != id }
                .toMutableList()
            current.add(0, id)
            val trimmed = current.take(30)
            prefs[recentIdsKey] = trimmed.joinToString(",")
        }
    }
}
