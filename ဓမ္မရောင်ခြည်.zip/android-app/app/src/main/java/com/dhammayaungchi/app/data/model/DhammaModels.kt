package com.dhammayaungchi.app.data.model

enum class MediaType(val labelBurmese: String) {
    MP3("MP3 အသံတော်"),
    MP4("MP4 ဗီဒီယို")
}

object DhammaCategories {
    const val ALL = "အားလုံး"
    val LIST = listOf(
        "တရားတော်",
        "ပရိတ်တော်",
        "ပဋ္ဌာန်း",
        "ဝိပဿနာ",
        "ဓမ္မစကြာ",
        "ဂါထာတော်"
    )
}

data class DhammaContent(
    val id: String = "",
    val title: String = "",
    val preacher: String = "",
    val category: String = DhammaCategories.LIST.first(),
    val description: String = "",
    val mediaType: MediaType = MediaType.MP3,
    val mediaUrl: String = "",
    val durationText: String = "00:00",
    val createdAt: String = "",
    val updatedAt: String = ""
)

data class AdminSessionState(
    val isChecking: Boolean = false,
    val isServerConfigured: Boolean = true,
    val isAdminAuthenticated: Boolean = false,
    val email: String? = null,
    val errorMessage: String? = null
)

data class UploadProgressState(
    val isUploading: Boolean = false,
    val statusMessage: String = ""
)
