package com.dhammayaungchi.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dhammayaungchi.app.R
import com.dhammayaungchi.app.data.model.DhammaCategories
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.data.model.MediaType
import com.dhammayaungchi.app.ui.components.DhammaTalkCard
import com.dhammayaungchi.app.ui.theme.*
import com.dhammayaungchi.app.ui.viewmodel.DhammaUiState

@Composable
fun HomeScreen(
    uiState: DhammaUiState,
    activeAudioId: String?,
    onSelectCategory: (String) -> Unit,
    onSelectMediaType: (MediaType?) -> Unit,
    onPlayItem: (DhammaContent) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepTeakBackground),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Buddhist Sanctuary Card with Imagery
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hero_pagoda_sunrise),
                    contentDescription = "ရွှေတိဂုံစေတီတော်နှင့် ဗုဒ္ဓဘာသာ ပုံရိပ်",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    DeepTeakBackground.copy(alpha = 0.65f),
                                    DeepTeakBackground.copy(alpha = 0.96f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp)
                ) {
                    Text(
                        text = "ဓမ္မရောင်ခြည်",
                        style = MaterialTheme.typography.headlineLarge,
                        color = BurnishedGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "တရားဓမ္မ အသံတော်နှင့် ဗီဒီယိုတရားတော်များကို အချိန်မရွေး နားဆင်ကြည့်ရှုနိုင်ပါသည်",
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryText
                    )
                }
            }
        }

        // Category Filter Row
        item {
            val allCategories = listOf(DhammaCategories.ALL) + DhammaCategories.LIST
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(allCategories) { category ->
                    val selected = uiState.selectedCategory == category
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectCategory(category) },
                        label = {
                            Text(
                                text = category,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AntiqueGold,
                            selectedLabelColor = DeepTeakBackground,
                            containerColor = TempleBrownSurface,
                            labelColor = WarmSandText
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selected,
                            borderColor = HairlineBrownBorder,
                            selectedBorderColor = AntiqueGold
                        )
                    )
                }
            }
        }

        // Media Type Filter Segment
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val options: List<Pair<MediaType?, String>> = listOf(
                    null to "အားလုံး",
                    MediaType.MP3 to "MP3 အသံ",
                    MediaType.MP4 to "MP4 ဗီဒီယို"
                )
                options.forEach { (type, label) ->
                    val active = uiState.selectedMediaFilter == type
                    OutlinedButton(
                        onClick = { onSelectMediaType(type) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (active) ElevatedBrownSurface else Color.Transparent,
                            contentColor = if (active) BurnishedGold else WarmSandText
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (active) AntiqueGold else HairlineBrownBorder
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = label, maxLines = 1)
                    }
                }
            }
        }

        // Section Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "တရားတော်များ (${uiState.filteredContents.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = IvoryText
                )
            }
        }

        if (uiState.isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = AntiqueGold)
                }
            }
        } else if (uiState.errorMessage != null) {
            item {
                Surface(
                    color = TempleBrownSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, LotusCrimson)
                ) {
                    Text(
                        text = uiState.errorMessage,
                        color = IvoryText,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else if (uiState.filteredContents.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = TempleBrownSurface,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, HairlineBrownBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "တရားတော်များ မရှိသေးပါ",
                            style = MaterialTheme.typography.titleMedium,
                            color = BurnishedGold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "စီမံခန့်ခွဲသူ (Admin) မှ MP3 သို့မဟုတ် MP4 တရားတော်များကို တင်သွင်းပေးပါမည်။",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmSandText
                        )
                    }
                }
            }
        } else {
            items(uiState.filteredContents, key = { it.id }) { item ->
                DhammaTalkCard(
                    item = item,
                    isFavorite = uiState.favoriteIds.contains(item.id),
                    isCurrentlyPlaying = activeAudioId == item.id,
                    onPlayClick = { onPlayItem(item) },
                    onToggleFavorite = { onToggleFavorite(item.id) }
                )
            }
        }
    }
}
