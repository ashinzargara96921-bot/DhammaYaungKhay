package com.dhammayaungchi.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.dhammayaungchi.app.R
import com.dhammayaungchi.app.data.model.DhammaContent
import com.dhammayaungchi.app.player.AudioPlayerUiState
import com.dhammayaungchi.app.ui.components.formatMillisToTime
import com.dhammayaungchi.app.ui.theme.*

@Composable
fun FullAudioPlayerScreen(
    audioState: AudioPlayerUiState,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onSkipBy: (Long) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onClose: () -> Unit
) {
    val track = audioState.activeTrack ?: return
    val duration = audioState.durationMs.coerceAtLeast(1L)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "ပိတ်ရန်", tint = IvoryText)
            }
            Text("MP3 တရားတော် နားဆင်ခြင်း", color = WarmSandText, style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "နှစ်သက်ရာ",
                    tint = if (isFavorite) AntiqueGold else WarmSandText
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Image(
            painter = painterResource(id = R.drawable.buddha_statue_gold),
            contentDescription = track.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(260.dp)
                .clip(RoundedCornerShape(24.dp))
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = track.title,
            style = MaterialTheme.typography.headlineMedium,
            color = BurnishedGold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "${track.preacher} · ${track.category}",
            style = MaterialTheme.typography.bodyMedium,
            color = WarmSandText
        )

        Spacer(modifier = Modifier.height(24.dp))

        Slider(
            value = audioState.currentPositionMs.toFloat(),
            onValueChange = { onSeekTo(it.toLong()) },
            valueRange = 0f..duration.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = BurnishedGold,
                activeTrackColor = AntiqueGold,
                inactiveTrackColor = HairlineBrownBorder
            )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatMillisToTime(audioState.currentPositionMs), color = WarmSandText, style = MaterialTheme.typography.labelMedium)
            Text(formatMillisToTime(audioState.durationMs), color = WarmSandText, style = MaterialTheme.typography.labelMedium)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            IconButton(onClick = { onSkipBy(-15_000L) }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.Replay10, contentDescription = "၁၅ စက္ကန့် နောက်ဆုတ်", tint = IvoryText, modifier = Modifier.size(34.dp))
            }

            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(AntiqueGold),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onTogglePlayPause, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (audioState.isPlaying) "ခေတ္တရပ်ရန်" else "ဖွင့်ရန်",
                        tint = DeepTeakBackground,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            IconButton(onClick = { onSkipBy(15_000L) }, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.Forward10, contentDescription = "၁၅ စက္ကန့် ရှေ့တိုး", tint = IvoryText, modifier = Modifier.size(34.dp))
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { speed ->
                val active = audioState.playbackSpeed == speed
                OutlinedButton(
                    onClick = { onSpeedChange(speed) },
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (active) ElevatedBrownSurface else DeepTeakBackground,
                        contentColor = if (active) BurnishedGold else WarmSandText
                    )
                ) {
                    Text("${speed}x")
                }
            }
        }
    }
}

@Composable
fun VideoPlayerScreen(
    item: DhammaContent,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember(item.mediaUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(item.mediaUrl))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepTeakBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "နောက်သို့", tint = IvoryText)
            }
            Text("MP4 ဗီဒီယို တရားတော်", color = BurnishedGold, style = MaterialTheme.typography.titleMedium)
            IconButton(onClick = onToggleFavorite) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "နှစ်သက်ရာ",
                    tint = if (isFavorite) AntiqueGold else WarmSandText
                )
            }
        }

        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
        )

        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.headlineMedium,
                color = BurnishedGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${item.preacher} · ${item.category} · ${item.durationText}",
                style = MaterialTheme.typography.bodyMedium,
                color = WarmSandText
            )
            if (item.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = item.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = IvoryText
                )
            }
        }
    }
}
