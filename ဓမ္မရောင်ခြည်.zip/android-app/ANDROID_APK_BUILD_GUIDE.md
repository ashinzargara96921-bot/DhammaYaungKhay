# ဓမ္မရောင်ခြည် (Dhamma Yaung Chi) — Android APK Build Guide (No Firebase Required)

Firebase မလိုအပ်ဘဲ Express Backend (သို့မဟုတ် ကိုယ်ပိုင် Server URL) နှင့် ချိတ်ဆက်အသုံးပြုနိုင်သော Android APK ထုတ်လုပ်ရန် အဆင့်ဆင့် လမ်းညွှန် ဖြစ်ပါသည်။

## ၁။ လိုအပ်ချက်များ (Prerequisites)
- **Android Studio** (Ladybug / Jellyfish သို့မဟုတ် နောက်ဆုံးဗားရှင်း) သို့မဟုတ် **JDK 17 + Android SDK (API 35)**
- **Gradle 8.9** (Android Studio မှ အလိုအလျောက် ဒေါင်းလုဒ်ဆွဲပေးပါမည်)

## ၂။ Android Studio ဖြင့် APK ထုတ်နည်း
1. `android-app/` ဖိုလ်ဒါကို Android Studio တွင် **File → Open** ဖြင့် ဖွင့်ပါ။
2. Gradle Sync ပြီးဆုံးသည်အထိ စောင့်ပါ (`google-services.json` မလိုအပ်ပါ)။
3. စမ်းသပ်ရန် Debug APK ထုတ်လိုပါက:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)** ကို နှိပ်ပါ။
   - ထွက်လာသော APK လမ်းကြောင်း: `app/build/outputs/apk/debug/app-debug.apk`
4. Command line ဖြင့် ထုတ်လိုပါက (JDK 17 နှင့် Android SDK ရှိသောစက်တွင်):
   ```bash
   cd android-app
   gradle assembleDebug
   ```
   (သို့မဟုတ် Release APK အတွက် `Build → Generate Signed Bundle / APK` မှ keystore ရွေးချယ်၍ ထုတ်နိုင်ပါသည်။)

## ၃။ Server URL ချိတ်ဆက်ပုံ
- Default Server URL ကို `app/build.gradle.kts` ထဲရှိ `DEFAULT_SERVER_URL` တွင် သတ်မှတ်ထားပါသည်။
- ဖုန်းပေါ်ရှိ App အတွင်း **စီမံသူ (Admin)** တဘ်မှ **ဆာဗာလိပ်စာ (Server URL)** ကို အချိန်မရွေး ပြောင်းလဲသိမ်းဆည်းနိုင်ပါသည်:
  - Android Emulator ဖြင့် Local Server စမ်းသပ်ပါက: `http://10.0.2.2:3000`
  - Wi-Fi တူညီသော ဖုန်းအစစ်ဖြင့် Local Server စမ်းသပ်ပါက: `http://<PC_LAN_IP>:3000`
  - Live Server URL (Shared/Cloud Run/VPS): `https://your-server-domain`
